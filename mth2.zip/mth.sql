-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2020 at 05:00 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mth`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointement`
--

CREATE TABLE `appointement` (
  `app_id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `fname` varchar(10) DEFAULT NULL,
  `lname` varchar(10) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `from_time` int(11) DEFAULT NULL,
  `to_time` int(11) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `contact` bigint(12) DEFAULT NULL,
  `doc_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointement`
--

INSERT INTO `appointement` (`app_id`, `patient_id`, `fname`, `lname`, `date`, `status`, `gender`, `from_time`, `to_time`, `email`, `contact`, `doc_id`) VALUES
(1, 2, 'bijal', 'patel', '2020-11-26', 'Test', '', 11, 0, 'mrunaligavare1997@gm', 988766543, NULL),
(2, 2, 'bijal', 'patel', '2020-11-26', 'Test', '', 11, 0, 'mrunaligavare1997@gm', 988766543, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `fname` varchar(10) NOT NULL,
  `lname` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `feedback` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_id`, `patient_id`, `fname`, `lname`, `email`, `feedback`) VALUES
(1, 2, 'bijal', 'patel', 'mrunaligavare1997@gm', 'Best Treatment Ever');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `pres_id` int(11) NOT NULL,
  `patient_name` varchar(20) DEFAULT NULL,
  `pres_date` date DEFAULT NULL,
  `prescription` varchar(255) DEFAULT NULL,
  `symptoms` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`pres_id`, `patient_name`, `pres_date`, `prescription`, `symptoms`) VALUES
(4, 'Test', '2020-11-27', '600px-No_image_available.svg.png', 'Test'),
(5, 'P1', '2020-11-29', '1200px-No_image_3x4.svg.png', 'Testfsdvsdv');

-- --------------------------------------------------------

--
-- Table structure for table `p_inquiry`
--

CREATE TABLE `p_inquiry` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `p_inquiry`
--

INSERT INTO `p_inquiry` (`id`, `name`, `email`, `date`, `phone`, `message`) VALUES
(1, 'Shreyas Kheni', 'shreyaskheni2@gmail.com', '2020-11-27', '+918306561155', 'Test');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(16) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact` bigint(10) NOT NULL,
  `address` varchar(30) NOT NULL,
  `city` varchar(15) NOT NULL,
  `state` varchar(20) NOT NULL,
  `roll_id` varchar(25) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `fname`, `lname`, `dob`, `gender`, `email`, `contact`, `address`, `city`, `state`, `roll_id`, `username`, `password`) VALUES
(1, 'manali', 'patel', '0000-00-00', 'Male', 'mrunaligavare1997@gmail.com', 0, 'vgc', 'Ahmedabad', 'punjab', 'patient', 'helly', '1997'),
(2, 'bijal', 'patel', '1999-04-18', 'Female', 'mrunaligavare1997@gmail.com', 988766543, 'ihgfdsxcvv', 'Ahmedabad', 'gujrat', '', 'mrunali', '12345'),
(11, 'sakshi', 'gavare', '2000-01-11', 'Female', 'shreyaskheni2@gmail.com', 988776659, 'jdcywcdy', 'Baroda', 'gujrat', '', 'sakshi', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointement`
--
ALTER TABLE `appointement`
  ADD PRIMARY KEY (`app_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`pres_id`);

--
-- Indexes for table `p_inquiry`
--
ALTER TABLE `p_inquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointement`
--
ALTER TABLE `appointement`
  MODIFY `app_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `pres_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `p_inquiry`
--
ALTER TABLE `p_inquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=221;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
