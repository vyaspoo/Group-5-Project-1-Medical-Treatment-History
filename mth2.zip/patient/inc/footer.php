<br/> </br> 
<footer class="main-footer pt-60">
            <div class="container">
                <div class="footer-widgets">
                    <div class="row row-masnory">
                        <div class="col-md-6 col-sm-6 pb-50">
                            <div class="widget">
                                <h2>About us</h2>
                                <p class="mb-10">Medical treatment history is developed in order to maintain the history and buy the online any type of medicine.This web application will provide the facility.</p>
                                <p class="mb-10">Patient can buy medicines online, track the location and also can see the events. Patient can see the medical history.</p>
                              
                            </div>
                        </div>
                        
                        <div class="col-md-6 col-sm-6 pb-50">
                            <div class="widget get-in-touch">
                                <h2>Opening Hours</h2>
                                <ul class="opening-hours">
                                    <li>Monday – Thursday <span class="float-right">8.00 – 17.00</span></li>
                                    <li>Friday <span class="float-right">9.30 – 17.30</span></li>
                                    <li>Saturday <span class="float-right">9.30 – 15.00</span></li>
                                    <li>Sunday <span class="float-right">Closing</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="sub-footer">
                <div class="container">
                    <h6 class="copyright"> MTH © Copyright 2018. All rights reserved. </h6>
                </div>
            </div>
        </footer>
        <!-- –––––––––––––––[ END FOOTER ]––––––––––– -->

    </div>
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- END WRAPPER                               -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->


    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- BACK TO TOP                               -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <div id="backTop" class="back-top is-hidden-sm-down">
        <i class="fa fa-angle-up" aria-hidden="true"></i>
    </div>

    <div class="layout-options">
        <div class="box-layout">
            <a href="#" id="rtl-link" class="btn btn-block">Switch To RTL</a><br><a href="https://themeforest.net/item/health-medical-dentist-doctor-clinic-and-hospital-template-imedical/19747019?ref=CODASTROID" class="btn btn-block buy-btn">Buy Now</a>
        </div>
        <div class="icon-cog">
            <i class="fa fa-cog lay fa-spin"></i>
        </div>
    </div>

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- SCRIPTS                                   -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->

    <!-- (!) Placed at the end of the document so the pages load faster -->

    <!-- =========[ jQuery library ]========= -->
    <script src="assets/js/jquery-1.12.3.min.js"></script>

    <!-- ========[ Latest Bootstrap ]======== -->
    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>

    <!-- ========[ JavaScript Plugins ]======== -->
    <!-- (!) Include all compiled plugins (below), or include individual files as needed -->

    <!-- Owl Carousel -->
    <script type="text/javascript" src="assets/vendors/owl-carousel/owl.carousel.min.js"></script>

    <!-- Magnific popup -->
    <script type="text/javascript" src="assets/vendors/magnific-popup/js/jquery.magnific-popup.min.js"></script>

    <!-- jQuery Easing v1.3 -->
    <script type="text/javascript" src="assets/vendors/jquery.easing.1.3.min.js"></script>

    <!-- MixItUp v2.1.11 -->
    <script type="text/javascript" src="assets/vendors/jquery.mixitup.js"></script>

    <!-- Bootstrap Datepicker -->
    <script type="text/javascript" src="assets/vendors/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>

    <!-- YTPlayer -->
    <script type="text/javascript" src="assets/vendors/YTPlayer/js/jquery.mb.YTPlayer.min.js"></script>

    <!-- =====[ Custom Template JavaScript ]===== -->
    <script type="text/javascript" src="assets/js/main.js"></script>
    <script type="text/javascript" src="assets/js/demo.js"></script>
</body>


<!-- Mirrored from imedical-theme.firebaseapp.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 16 Jan 2018 07:54:24 GMT -->
</html>