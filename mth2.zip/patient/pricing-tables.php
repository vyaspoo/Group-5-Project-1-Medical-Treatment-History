<?php include './inc/header.php';?>        <!-- –––––––––––––––[ HEADER ]––––––––––––––– -->

		<!-- –––––––––––––––[ PAGE CONTENT ]––––––––––––––– -->
		<main id="mainContent" class="main-content">

            <!-- Start Hero Area -->
            <section class="section breadcrumb-area pt-100 pb-80" data-bg-img="assets/images/slider/01.jpg">
                <div class="container t-center">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
                            <div class="section-top-title">
                                <h1 class="t-uppercase font-45">Pricing Tables</h1>
                                <ol class="breadcrumb">
                                    <li><a href="index-3.html"><i class="fa fa-home mr-10"></i>Home</a></li>
                                    <li class="active">Pricing Tables</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- End Hero Area -->

            <!-- Start Pricing Table Area  -->
            <section class="section pricing-area pt-70 pb-80">
                <div class="container">
                    <div class="row mb-30">
                        <div class="col-lg-7 col-md-8 col-sm-10 col-xs-12 col-xs-center t-center mb-40">
                            <h6 class="section-subtitle mb-10 t-uppercase color-mid">Select Your Plan</h6>
                            <h2 class="section-title mb-20 font-22 t-uppercase">OUR PRICING TABLES</h2>
                            <div class="heart-line">
                                <img src="assets/images/icon.png" alt="Awesome Image">
                            </div>
                        </div>
                    </div>
                    <div class="row row-rl-0 pricing-tables-list">
                        <div class="col-md-4 pricing-table mt-20">
                            <div class="plan-title-box bg-theme ptb-20">
                                <h3>Basic</h3>
                            </div>
                            <div class="plan-price-box t-center">
                                <span class="font-50 color-theme valign-baseline"><sup class="font-30">$</sup>29</span>
                                <span class="t-uppercase color-mid">per hour</span>
                            </div>
                            <div class="text-left">
                                <ul class="features-list">
                                    <li><i class="fa fa-check mr-10"></i>Crowns & Bridges</li>
                                    <li><i class="fa fa-check mr-10"></i>Root Canals</li>
                                    <li><i class="fa fa-check mr-10"></i>Whitening</li>
                                    <li><i class="fa fa-times mr-10"></i>Dental Implants</li>
                                    <li><i class="fa fa-times mr-10"></i>Cosmetic Dentistry</li>
                                </ul>
                            </div>
                            <div class="plan-btn t-center ptb-15">
                                <a href="#" class="btn btn-lg">order now</a>
                            </div>
                        </div>
                        <div class="col-md-4 pricing-table recommended">
                            <div class="plan-title-box bg-blue-dark ptb-30">
                                <h3>Regular</h3>
                            </div>
                            <div class="plan-price-box t-center">
                                <span class="font-50 color-theme valign-baseline"><sup class="font-30">$</sup>69</span>
                                <span class="t-uppercase color-mid">per hour</span>
                            </div>
                            <div class="text-left">
                                <ul class="features-list">
                                    <li><i class="fa fa-check mr-10"></i>Crowns & Bridges</li>
                                    <li><i class="fa fa-check mr-10"></i>Root Canals</li>
                                    <li><i class="fa fa-check mr-10"></i>Whitening</li>
                                    <li><i class="fa fa-check mr-10"></i>Dental Implants</li>
                                    <li><i class="fa fa-times mr-10"></i>Cosmetic Dentistry</li>
                                </ul>
                            </div>
                            <div class="plan-btn t-center ptb-20">
                                <a href="#" class="btn btn-lg">order now</a>
                            </div>
                        </div>
                        <div class="col-md-4 pricing-table mt-20">
                            <div class="plan-title-box bg-blue-darker ptb-20">
                                <h3>Pro</h3>
                            </div>
                            <div class="plan-price-box t-center">
                                <span class="font-50 color-theme valign-baseline"><sup class="font-30">$</sup>99</span>
                                <span class="t-uppercase color-mid">per hour</span>
                            </div>
                            <div class="text-left">
                                <ul class="features-list">
                                    <li><i class="fa fa-check mr-10"></i>Crowns & Bridges</li>
                                    <li><i class="fa fa-check mr-10"></i>Root Canals</li>
                                    <li><i class="fa fa-check mr-10"></i>Whitening</li>
                                    <li><i class="fa fa-check mr-10"></i>Dental Implants</li>
                                    <li><i class="fa fa-check mr-10"></i>Cosmetic Dentistry</li>
                                </ul>
                            </div>
                            <div class="plan-btn t-center ptb-15">
                                <a href="#" class="btn btn-lg">order now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- End Pricing Table Area  -->



		</main>
		<!-- –––––––––––––––[ END PAGE CONTENT ]––––––––––––––– -->

		<!-- –––––––––––––––[ FOOTER ]––––––––––––––– -->
		<?php include './inc/footer.php';?>