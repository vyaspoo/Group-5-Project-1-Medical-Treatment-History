<?php include './inc/header.php';?>        <!-- –––––––––––––––[ HEADER ]––––––––––––––– -->

		<!-- –––––––––––––––[ PAGE CONTENT ]––––––––––––––– -->
		<main id="mainContent" class="main-content">

			<!-- Start Hero Area -->
			<section class="section breadcrumb-area bg-ct pt-100 pb-80" data-bg-img="assets/images/slider/01.jpg">
                <div class="container t-center">
	            	<div class="row">
		            	<div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
							<div class="section-top-title">
								<h1 class="t-uppercase font-45">About Us</h1>
								<ol class="breadcrumb">
								  <li><a href="index.php"><i class="fa fa-home mr-10"></i>Home</a></li>
								  <li class="active">About Us</li>
								</ol>
							</div>
						</div>
					</div>
				</div>
            </section>
                        <br/><br/>
            <!-- End Hero Area -->

		    <!-- Start About Us Area -->
		  
		    <!-- End About Us Area -->

			<!-- start about section  -->
			<div class="section about-us-area about-us-area-2 ptb-60 bg-gray">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-images">
							<div class="about-images">
								<img src="assets/images/about/about.jpg" alt="">
							</div>
						</div>
						<div class="col-md-6 col-content">
							<h6 class="mb-15 color-theme">Welcome to MTH</h6>
							<h2 class="mb-15 font-22 t-uppercase">Welcome to Medical Treatement History</h2>
							<p class="color-mid mb-15">Medical treatment history is developed in order to maintain the history and buy the online any type of medicine.This web application will provide the facility like online shopping or 1MG.</p>
							<p class="color-mid mb-20">Patient can buy medicines online, track the location and also can see the events. Patient can see the medical history</p>
                                                        <a href="doctor-details.php" class="btn btn-lg btn-rounded">Our Doctors</a>
						</div>
					</div>
				</div>
			</div>
			<!-- end about section  -->

		    <!-- Start About Company Area -->
		    <section class="section about-hospital-area ptb-60">
		    	<div class="container">
		    		<div class="row mb-30">
                        <div class="col-lg-7 col-md-8 col-sm-10 col-xs-12 col-xs-center t-center mb-40">
                        	<h6 class="section-subtitle mb-10 t-uppercase color-mid">How We Are</h6>
                            <h2 class="section-title mb-20 font-22 t-uppercase">WE GIVE YOU THE BEST</h2>
                            <div class="heart-line">
                            	<img src="assets/images/icon.png" alt="Awesome Image">
                            </div>
                        </div>
                    </div>
                    <div class="row row-tb-15">
                    	<div class="col-md-4">
                    		<div class="column">
								<div class="icon">
									<img src="assets/images/icons/i-02.png" alt="icon">
								</div>
								<div class="contrive-icon-text-holder">
									<h6 class="t-uppercase mb-15">Gynecologist</h6>
									<p class="color-mid">The medical speciality that deals with gynecology.gynecologiest to be adept at the care of female's health.</p>
								</div>
							</div>
                    	</div>
                    	<div class="col-md-4">
                    		<div class="column">
								<div class="icon">
									<img src="assets/images/icons/i-03.png" alt="icon">
								</div>
								<div class="contrive-icon-text-holder">
									<h6 class="t-uppercase mb-15">Diabetes Specialist</h6>
									<p class="color-mid">Diabetes often referred by doctors as mellitus a group of metabolic diseases in which the person high blood glucose.</p>
								</div>
							</div>
                    	</div>
                    	<div class="col-md-4">
                    		<div class="column">
								<div class="icon">
                                                                    <img src="assets/images/3.jpg" alt="icon">
								</div>
								<div class="contrive-icon-text-holder">
									<h6 class="t-uppercase mb-15">Child Specialist</h6>
									<p class="color-mid">Child life specialists work closely with children and families in medical settings, serving as emotional.</p>
								</div>
							</div>
                    	</div>
                    	<div class="col-md-4">
                    		<div class="column">
								<div class="icon">
									<img src="assets/images/icons/i-05.png" alt="icon">
								</div>
								<div class="contrive-icon-text-holder">
									<h6 class="t-uppercase mb-15">Physiotherapiest</h6>
									<p class="color-mid">Physiotherapy aims at providing relief to patients suffering from bone and joint ailments by promoting mobility.</p>
								</div>
							</div>
                    	</div>
                    	<div class="col-md-4">
                    		<div class="column">
								<div class="icon">
									<img src="assets/images/1.jpg" alt="icon">
								</div>
								<div class="contrive-icon-text-holder">
									<h6 class="t-uppercase mb-15">Dentist</h6>
									<p class="color-mid">Maecenas eget libero at tellus mattis porta sed venenatis lorem. Sed ultricies, metus non maximus vulputate.</p>
								</div>
							</div>
                    	</div>
                    	<div class="col-md-4">
                    		<div class="column">
								<div class="icon">
									<img src="assets/images/icons/i-07.png" alt="icon">
								</div>
								<div class="contrive-icon-text-holder">
									<h6 class="t-uppercase mb-15">Eye Specialist</h6>
									<p class="color-mid">Eye care optometry refers to care taken to prevent and diagnose eye related problems. Eye </p>
								</div>
							</div>
                    	</div>
                    </div>
		    	</div>
		    </section>
		    <!-- End  About Company Area -->

		    <!-- Start Our Team Area -->
            <section class="section team-area pt-80 pb-40 bg-gray">
		    	<div class="container">
		    		<div class="row mb-30">
                        <div class="col-lg-7 col-md-8 col-sm-10 col-xs-12 col-xs-center t-center mb-40">
                        	<h6 class="section-subtitle mb-10 t-uppercase color-mid">How We Are</h6>
                            <h2 class="section-title mb-20 font-22 t-uppercase">Meet Our Specialists</h2>
                            <div class="heart-line">
                            	<img src="assets/images/icon.png" alt="Awesome Image">
                            </div>
                        </div>
                    </div>
	            	<div class="team-members row">
	                    <div class="col-md-3 col-sm-6">
	                        <div class="single-member">
	                            <div class="single-member-header">
	                                <img src="assets/images/doctors/01.jpg" alt="">
	                               
	                            </div>
	                            <div class="single-member-content">
	                                <h5 class="mb-10 font-15 t-uppercase"><a href="doctor-details-2.html">DR. Isabella Garcia</a></h5>
	                                <h6 class="color-mid font-12 t-uppercase mb-5">Gynecologiest</h6>
	                            </div>
	                        </div>
	                    </div>
	                    <div class="col-md-3 col-sm-6">
	                        <div class="single-member">
	                            <div class="single-member-header">
	                                <img src="assets/images/doctors/02.jpg" alt="">
	                               
	                            </div>
	                            <div class="single-member-content">
	                                <h5 class="mb-10 font-15 t-uppercase"><a href="doctor-details-2.html">DR. James White</a></h5>
	                                <h6 class="color-mid font-12 t-uppercase mb-5">child Specialist</h6>
	                            </div>
	                        </div>
	                    </div>
	                    <div class="col-md-3 col-sm-6">
	                        <div class="single-member">
	                            <div class="single-member-header">
	                                <img src="assets/images/doctors/04.jpg" alt="">
	                                
	                            </div>
	                            <div class="single-member-content">
	                                <h5 class="mb-10 font-15 t-uppercase"><a href="doctor-details-2.html">DR. Daniel Harris</a></h5>
	                                <h6 class="color-mid font-12 t-uppercase mb-5">dentist</h6>
	                            </div>
	                        </div>
	                    </div>
	                    <div class="col-md-3 col-sm-6">
	                        <div class="single-member">
	                            <div class="single-member-header">
	                                <img src="assets/images/doctors/03.jpg" alt="">
	                               
	                            </div>
	                            <div class="single-member-content">
	                                <h5 class="mb-10 font-15 t-uppercase"><a href="doctor-details-2.html">DR. Martin Allen</a></h5>
	                                <h6 class="color-mid font-12 t-uppercase mb-5">diabetes Specialist</h6>
	                            </div>
	                        </div>
	                    </div>
	                </div>
		        </div>
		    </section>
		    <!-- End Our Team Area -->

		    <!-- Start Gallery Area  -->
			<section class="section portifolio-area portifolio-area-1 ptb-60">
				<div class="container">
					<div class="row mb-30">
                        <div class="col-lg-7 col-md-8 col-sm-10 col-xs-12 col-xs-center t-center mb-40">
                        	<h6 class="section-subtitle mb-10 t-uppercase color-mid">The services we offer</h6>
                            <h2 class="section-title mb-20 font-22 t-uppercase">Our Gallery</h2>
                            <div class="heart-line">
                            	<img src="assets/images/icon.png" alt="Awesome Image">
                            </div>
                        </div>
                    </div>
					<div class="portifolio-filter">
						<div>
							<a href="#" class="filter" data-filter="all">All</a>
						</div>
						<div>
							<a href="#" class="filter" data-filter=".laboratory">Laboratory</a>
						</div>
						<div>
							<a href="#" class="filter" data-filter=".sexual">Sexual Health</a>
						</div>
						<div>
							<a href="#" class="filter" data-filter=".neurology">Neurology</a>
						</div>
						<div>
							<a href="#" class="filter" data-filter=".otology">Otology</a>
						</div>
					</div>
					<div class="portifolio-wrapper row row-tb-10 row-rl-10">
						<div class="mix col-xs-6 col-sm-4 col-md-3 laboratory neurology">
							<div class="portifolio-single">
								<img src="assets/images/gallery/1.jpg" alt="" />
								
							</div>
						</div>
						<div class="mix col-xs-6 col-sm-4 col-md-3 neurology otology sexual">
							<div class="portifolio-single">
								<img src="assets/images/gallery/2.jpg" alt="" />
								
							</div>
						</div>
						<div class="mix col-xs-6 col-sm-4 col-md-3 sexual laboratory">
							<div class="portifolio-single">
								<img src="assets/images/gallery/3.jpg" alt="" />
								
							</div>
						</div>
						<div class="mix col-xs-6 col-sm-4 col-md-3 otology sexual">
							<div class="portifolio-single">
								<img src="assets/images/gallery/4.jpg" alt="" />
								
							</div>
						</div>
						<div class="mix col-xs-6 col-sm-4 col-md-3 neurology laboratory">
							<div class="portifolio-single">
								<img src="assets/images/gallery/5.jpg" alt="" />
								
							</div>
						</div>
						<div class="mix col-xs-6 col-sm-4 col-md-3 sexual otology neurology">
							<div class="portifolio-single">
								<img src="assets/images/gallery/6.jpg" alt="" />
								
							</div>
						</div>
						<div class="mix col-xs-6 col-sm-4 col-md-3 otology laboratory sexual">
							<div class="portifolio-single">
								<img src="assets/images/gallery/7.jpg" alt="" />
								
							</div>
						</div>
						<div class="mix col-xs-6 col-sm-4 col-md-3 otology laboratory neurology">
							<div class="portifolio-single">
								<img src="assets/images/gallery/8.jpg" alt="" />
								
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- end Gallery section  -->



		</main>
		<!-- –––––––––––––––[ END PAGE CONTENT ]––––––––––––––– -->

		<!-- –––––––––––––––[ FOOTER ]––––––––––––––– -->
	<?php include './inc/footer.php';?>