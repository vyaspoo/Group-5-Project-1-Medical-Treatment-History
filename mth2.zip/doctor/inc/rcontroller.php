<?php
    include 'inc/model.php';
    $model=new model();
    
    
    include 'inc/connect.php';
    $obj=new connect();
    $con=$obj->get_connect();
    
    if(isset($_REQUEST["submit"]) || isset($_REQUEST["register"]) )
    {
        $fname=$_REQUEST["fname"];
        $lname=$_REQUEST["lname"];
        $ddate = str_replace("/","-",$_REQUEST["datepicker"]);
        $date=date("Y-m-d",strtotime($ddate));
        $gender=$_REQUEST["gender"];
        $email=$_REQUEST["email"];
        $contact=$_REQUEST["contact"];
         $address=$_REQUEST["address"];
         $city=$_REQUEST["city"];
         $state=$_REQUEST["state"];
        
        $uname=$_REQUEST["username"];
        $password=$_REQUEST["password"];
        
        
        $data=array(
                        "fname"=>$fname,
                        "lname"=>$lname,
                        "dob"=>$date,
                        "gender"=>$gender,
                        "email"=>$email,
                        "contact"=>$contact,
                        "address"=>$address,
                        "city"=>$city,
                        "state"=>$state,
                       
                        "username"=>$uname,
                        "password"=>$password,
                       
                        
                   );
        $model->insert($con,"registration", $data);
    }
   
    ?>