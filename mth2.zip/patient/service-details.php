
<?php include './inc/header.php';?>
        <!-- –––––––––––––––[ HEADER ]––––––––––––––– -->

		<!-- –––––––––––––––[ PAGE CONTENT ]––––––––––––––– -->
		<main id="mainContent" class="main-content">
			<!-- Start Hero Area -->
            <section class="section breadcrumb-area pt-100 pb-80" data-bg-img="assets/images/slider/01.jpg">
                <div class="container t-center">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
                            <div class="section-top-title">
                                <h1 class="t-uppercase font-45">Service Details</h1>
                                <ol class="breadcrumb">
                                    <li><a href="index.php"><i class="fa fa-home mr-10"></i>Home</a></li>
                                    <li class="active">Service Details</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- End Hero Area -->
               <section class="doctors-area doctors-list ptb-80">
                <div class="container">
                    <div class="row pb-80">
                        <div class="col-lg-4 col-md-5 ptb-6">
                            <h2 class="section-title mb-10 font-22 t-uppercase">Appointement</h2>
                            <figure class="embed-responsive embed-responsive-4by3 bg-ct" data-bg-img="assets/images/4.jpg" ></figure>
                        </div>
                        <div class="row-rl-5 ptb-10" style="margin-top:5%;">
                            
                            <p class="color-mid mb-10">Competently customize bricks-and-clicks core Competently customize bricks-and-clicks core competencies with adaptive leadership skills. Competently maintain intermandated. competencies with adaptive leadership skills. Competently maintain intermandated.</p>
                            <a href="appointment.php" class="btn btn-o btn-rounded">View More</a>
                        </div>
                    </div>
                    <div class="row pb-60">
                        <div class="col-lg-8 col-md-7 ptb-10">
                            
                            <p class="color-mid mb-20" style="margin-top:5%">Competently customize bricks-and-clicks core Competently customize bricks-and-clicks core competencies with adaptive leadership skills. Competently maintain intermandated. competencies with adaptive leadership skills. Competently maintain intermandated.</p>
                           <a href="articals.php" class="btn btn-o btn-rounded">View More</a>
                        </div>
                        <div class="col-lg-4 col-md-5 ptb-10">
                            <h2 class="section-title mb-10 font-22 t-uppercase">Articals</h2>
                            <figure class="embed-responsive embed-responsive-4by3 bg-ct" data-bg-img="assets/images/1111.jpg"></figure>
                        </div>
                    </div>
                    <div class="row pb-60">
                        <div class="col-lg-4 col-md-5 ptb-10">
                             <h2 class="section-title mb-10 font-22 t-uppercase">History</h2>
                            <figure class="embed-responsive embed-responsive-4by3 bg-ct" data-bg-img="assets/images/6.jpg"></figure>
                        </div>
                        <div class="col-lg-8 col-md-7 ptb-10">
                          
                            <p class="color-mid mb-20"style="margin-top:5%" >Competently customize bricks-and-clicks core Competently customize bricks-and-clicks core competencies with adaptive leadership skills. Competently maintain intermandated. competencies with adaptive leadership skills. Competently maintain intermandated.</p>
                            <a href="history.php" class="btn btn-o btn-rounded">View More</a>
                        </div>
                    </div>
                    <div class="row pb-60">
                        <div class="col-lg-8 col-md-7 ptb-10">
                           
                            <p class="color-mid mb-20" style="margin-top:5%">Competently customize bricksnd-clicks core Competently customize bricks-and-clicks core competencies with adaptive leadership skills. Competently maintain intermandated. competencies with adaptive leadership skills. Competently maintain intermandated.</p>
                            <a href="testimonials.php" class="btn btn-o btn-rounded">View More</a>
                        </div>
                        <div class="col-lg-4 col-md-5 ptb-10">
                             <h2 class="section-title mb-10 font-22 t-uppercase">Online Medicine</h2>
                            <figure class="embed-responsive embed-responsive-4by3 bg-ct" data-bg-img="assets/images/medicine.jpg"></figure>
                        </div>
                    </div>
                     <div class="row pb-80">
                        <div class="col-lg-4 col-md-5 ptb-6">
                            <h2 class="section-title mb-10 font-22 t-uppercase">Prescription</h2>
                            <figure class="embed-responsive embed-responsive-4by3 bg-ct" data-bg-img="assets/images/5.jpg" ></figure>
                        </div>
                        <div class="row-rl-5 ptb-10" style="margin-top:5%;">
                            
                            <p class="color-mid mb-10">Competently customize bricks-and-clicks core Competently customize bricks-and-clicks core competencies with adaptive leadership skills. Competently maintain intermandated. competencies with adaptive leadership skills. Competently maintain intermandated.</p>
                            <a href="gallery-02.php" class="btn btn-o btn-rounded">View More</a>
                        </div>
                    </div>
                    <div class="row pb-60">
                        <div class="col-lg-8 col-md-7 ptb-10">
                            
                            <p class="color-mid mb-20" style="margin-top:5%">Competently customize bricks-and-clicks core Competently customize bricks-and-clicks core competencies with adaptive leadership skills. Competently maintain intermandated. competencies with adaptive leadership skills. Competently maintain intermandated.</p>
                             <a href="inquiry.php" class="btn btn-o btn-rounded">View More</a>
                        </div>
                        <div class="col-lg-4 col-md-5 ptb-10">
                            <h2 class="section-title mb-10 font-22 t-uppercase">Ask Doctor</h2>
                            <figure class="embed-responsive embed-responsive-4by3 bg-ct" data-bg-img="assets/images/10.jpg"></figure>
                        </div>
                    </div>
                    
                </div>
            </section>

            <!-- Start Project Details Area -->
		 

		<!-- –––––––––––––––[ FOOTER ]––––––––––––––– -->
		<?php include './inc/footer.php';?>