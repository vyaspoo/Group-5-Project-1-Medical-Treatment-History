
<?php include './inc/header.php';?>
        <!-- –––––––––––––––[ HEADER ]––––––––––––––– -->

		<!-- –––––––––––––––[ PAGE CONTENT ]––––––––––––––– -->
		<main id="mainContent" class="main-content">
			<!-- Start Hero Area -->
			<section class="section breadcrumb-area pt-100 pb-80" data-bg-img="assets/images/slider/01.jpg">
                <div class="container t-center">
	            	<div class="row">
		            	<div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
							<div class="section-top-title">
								<h1 class="t-uppercase font-45">Our Services</h1>
								<ol class="breadcrumb">
                                                                    <li><a href="index.php"><i class="fa fa-home mr-10"></i>Home</a></li>
								  <li class="active">Our Services</li>
								</ol>
							</div>
						</div>
					</div>
				</div>
            </section>
            <!-- End Hero Area -->

            <!-- Start Services Area -->
            <section class="section services-area ptb-60">
                <div class="container">
                    <div class="row mb-5">
                        <div class="col-lg-7 col-md-8 col-sm-10 col-xs-12 col-xs-center t-center mb-40">
                            <h6 class="section-subtitle mb-10 t-uppercase color-mid">OUR OUTSTANDING SERVICES</h6>
                            <h2 class="section-title mb-20 font-22 t-uppercase">WHAT WE OFFER</h2>
                            <div class="heart-line">
                                <img src="assets/images/icon.png" alt="Awesome Image">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="service-single">
                                <div class="service-thumb">
                                    <img src="assets/images/4.jpg" alt="" height="auto;">
                                </div>
                                <div class="service-content">
                                    <h5 class="mb-10 t-uppercase color-theme">Appointement</h5>
                                    <p class="color-mid mb-15">All implant cases at Dentzz are performed by a team comprising of aesthetic dentists and implantologists. </p>
                                    <a class="btn btn-o btn-sm btn-rounded" href="service-details.php">Read more</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="service-single">
                                <div class="service-thumb">
                                    <img src="assets/images/medicine.jpg" alt="" height="auto;">
                                </div>
                                <div class="service-content">
                                    <h5 class="mb-10 t-uppercase color-theme">Online Medicine</h5>
                                    <p class="color-mid mb-15">All implant cases at Dentzz are performed by a team comprising of aesthetic dentists and implantologists. </p>
                                    <a class="btn btn-o btn-sm btn-rounded" href="service-details.php">Read more</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="service-single">
                                <div class="service-thumb">
                                    <img src="assets/images/1111.jpg" alt="" height="auto;">
                                </div>
                                <div class="service-content">
                                    <h5 class="mb-8 t-uppercase color-theme">Articals</h5>
                                    <p class="color-mid mb-15">All implant cases at Dentzz are performed by a team comprising of aesthetic dentists and implantologists. </p>
                                    <a class="btn btn-o btn-sm btn-rounded" href="service-details.php">Read more</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                             <div class="service-single">
                                 <div class="service-thumb" >
                                    <img src="assets/images/ask.jpg" alt="" width="340px" >
                                </div>
                                <div class="service-content">
                                    <h5 class="mb-8 t-uppercase color-theme">Ask doctor</h5>
                                    <p class="color-mid mb-15">All implant cases at Dentzz are performed by a team comprising of aesthetic dentists and implantologists. </p>
                                    <a class="btn btn-o btn-sm btn-rounded" href="service-details.php">Read more</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="service-single">
                                <div class="service-thumb">
                                    <img src="assets/images/6.jpg" alt="" width="220%" height="120">
                                </div>
                                <div class="service-content">
                                    <h5 class="mb-8 t-uppercase color-theme">Prescription</h5>
                                    <p class="color-mid mb-15">All implant cases at Dentzz are performed by a team comprising of aesthetic dentists and implantologists. </p>
                                    <a class="btn btn-o btn-sm btn-rounded" href="service-details.php">Read more</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                             <div class="service-single">
                                <div class="service-thumb">
                                    <img src="assets/images/5.jpg" alt="" height="auto;">
                                </div>
                                <div class="service-content">
                                    <h5 class="mb-8 t-uppercase color-theme">history</h5>
                                    <p class="color-mid mb-15">All implant cases at Dentzz are performed by a team comprising of aesthetic dentists and implantologists. </p>
                                    <a class="btn btn-o btn-sm btn-rounded" href="service-details.php">Read more</a>
                                </div>
                            </div>
                        </div>
                       
                      
                    </div>
                </div>
            </section>
            <!-- End Services Area -->
		    <!-- Start Call To Action -->
		   
		    <!-- End Call To Action -->

		    <section class="section departments-area pt-20">
                <div class="container">
                    <div class="row row-md-cell">
                        <div class="col-md-8 col-sm-12 pb-60">
                            <h2 class="t-uppercase mb-15 font-24">Our Departments</h2>
                            <div class="heart-line mb-20">
                            	<img src="assets/images/icon.png" alt="Awesome Image">
                            </div>
                            <p class="color-mid mb-40">
                                All of our activities are managed by the outpatient departments of internal medicine, including field offices in the Department of Cardiology and Department of Gastroenterology, Hepatology and Metabolism. In every department there are standard and specialized beds. The department also provides specialized units.
                            </p>
                            <div class="row departments-list row-tb-10 row-rl-10">
                                <div class="col-sm-3">
                                    <a href="" class="department-single">
                                    	<div class="department-single-inner t-center">
                                    		<div class="pos-tb-center">
                                            	<span class="department-icon icon-i-ear-nose-throat"></span><br>
                                            	<h6 class="department-name t-uppercase">Dental Care</h6>
                                    		</div>
                                        </div>
                                        <img src="assets/images/about/department-02.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-sm-3">
                                    <a href="" class="department-single">
                                    	<div class="department-single-inner t-center">
                                    		<div class="pos-tb-center">
                                            	<span class="department-icon icon-i-ear-nose-throat"></span><br>
                                            	<h6 class="department-name t-uppercase">Otology</h6>
                                    		</div>
                                        </div>
                                        <img src="assets/images/about/department-02.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-sm-3">
                                    <a href="" class="department-single">
                                    	<div class="department-single-inner t-center">
                                    		<div class="pos-tb-center">
                                            	<span class="department-icon icon-i-cardiology"></span><br>
                                            	<h6 class="department-name t-uppercase">Cardiac Clinic</h6>
                                    		</div>
                                        </div>
                                        <img src="assets/images/about/department-02.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-sm-3">
                                    <a href="" class="department-single">
                                    	<div class="department-single-inner t-center">
                                    		<div class="pos-tb-center">
                                            	<span class="department-icon icon-i-pediatrics"></span><br>
                                            	<h6 class="department-name t-uppercase">Hepatology</h6>
                                    		</div>
                                        </div>
                                        <img src="assets/images/about/department-02.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-sm-3">
                                    <a href="" class="department-single">
                                    	<div class="department-single-inner t-center">
                                    		<div class="pos-tb-center">
                                            	<span class="department-icon icon-i-surgery"></span><br>
                                            	<h6 class="department-name t-uppercase">Orthopedics</h6>
                                    		</div>
                                        </div>
                                        <img src="assets/images/about/department-02.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-sm-3">
                                    <a href="" class="department-single">
                                    	<div class="department-single-inner t-center">
                                    		<div class="pos-tb-center">
                                            	<span class="department-icon icon-i-internal-medicine"></span><br>
                                            	<h6 class="department-name t-uppercase">Neurology</h6>
                                    		</div>
                                        </div>
                                        <img src="assets/images/about/department-02.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-sm-3">
                                    <a href="" class="department-single">
                                    	<div class="department-single-inner t-center">
                                    		<div class="pos-tb-center">
                                            	<span class="department-icon icon-i-outpatient"></span><br>
                                            	<h6 class="department-name t-uppercase">Outpatient</h6>
                                    		</div>
                                        </div>
                                        <img src="assets/images/about/department-02.jpg" alt="">
                                    </a>
                                </div>
                                <div class="col-sm-3">
                                    <a href="" class="department-single">
                                    	<div class="department-single-inner t-center">
                                    		<div class="pos-tb-center">
                                            	<span class="department-icon icon-i-mental-health"></span><br>
                                            	<h6 class="department-name t-uppercase">Mental Health</h6>
                                    		</div>
                                        </div>
                                        <img src="assets/images/about/department-02.jpg" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 is-hidden-sm-down valign-bottom t-right">
                        	<img src="assets/images/about/department.jpg" alt="">
                        </div>
                    </div>
                </div>
            </section>



		</main>
		<!-- –––––––––––––––[ END PAGE CONTENT ]––––––––––––––– -->

		<!-- –––––––––––––––[ FOOTER ]––––––––––––––– -->
		<?php include './inc/footer.php'; ?> 