<?php
    include 'model.php';
    $model=new model();
    
    
    include 'connect.php';
    $obj=new connect();
    $con=$obj->get_connect();
    session_start();
 
    if(isset($_REQUEST["submit"]))
    {
        $username=$_REQUEST["username"];
        $password=$_REQUEST["password"];
        
        $data=array(
            "username"=>$username,
            "password"=>$password);
      $result=$model->login($con,"registration",$data);
      
      $rowcount=$result->num_rows;
      
  
    if($rowcount==1)
    {
        // if(isset($_REQUEST["remember"]))
       // {
          //  setcookie('username',"$username",time()+3600*24*1);
          //  setcookie('password',"$password",time()+3600*24*1);
        //}
        $row=$result->fetch_object();
       
        
        $_SESSION["puserid"]=$row->id;
        $_SESSION["name"]=$row->fname;
      
        header('location:./index.php');
    }
 else {
        echo "<script>alert('invalid username and password');</script>";  
}

    }
    
      
    
?>