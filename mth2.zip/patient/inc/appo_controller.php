<?php
    include 'model.php';
    $model=new model();

    include 'connect.php';
    $obj=new connect();
    $con=$obj->get_connect();
     session_start();

     $alluser=$model->select($con,"appointement");
    if(isset($_POST))
    {
        $fname=$_REQUEST["fname"];
        $lname=$_REQUEST["lname"];
        $date=$_REQUEST["date"];
        $status=$_REQUEST["message"];
        $gender=$_REQUEST["gender"];
        $ftime=$_REQUEST["from_time"];
        $ttime=$_REQUEST["to_time"];
        $email=$_REQUEST["email"];
        $contact=$_REQUEST["phone"];

        $data=array(
            "patient_id"=>$_SESSION["puserid"],
            "fname"=>$fname,
            "lname"=>$lname,
             "date"=>date("Y-m-d",strtotime($date)),
            "status"=>$status,
             "gender"=>$gender,
             "from_time"=>$ftime,
            "to_time"=>$ttime,
            "email"=>$email,
            "contact"=>$contact
            );
        $result=$model->insert($con,"appointement",$data);

    }
header("Location: ../appointment.php");
?>