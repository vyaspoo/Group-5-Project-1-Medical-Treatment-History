<?php include './inc/header.php';?>
<?php 
    $id=$_SESSION["puserid"];
    if(!isset($_SESSION["puserid"]))
    {
        header('location:index.php');
    }
    
?>

<!-- –––––––––––––––[ HEADER ]––––––––––––––– -->

		<!-- –––––––––––––––[ PAGE CONTENT ]––––––––––––––– -->
		<main id="mainContent" class="main-content">
			<!-- Start Hero Area -->
			<section class="section breadcrumb-area pt-100 pb-80" data-bg-img="assets/images/slider/01.jpg">
                <div class="container t-center">
	            	<div class="row">
		            	<div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
							<div class="section-top-title">
								<h1 class="t-uppercase font-45">inquiry</h1>
								<ol class="breadcrumb">
								  <li><a href="index.php"><i class="fa fa-home mr-10"></i>Home</a></li>
								  <li class="active">Inquiry</li>
								</ol>
							</div>
						</div>
					</div>
				</div>
            </section>
            <!-- End Hero Area -->

            <!-- Start appointment Area -->
            <section class="section appointment-area pt-60">
                <div class="container">
                    <div class="row mb-30">
                       
                    </div>
                    <div class="row services">
                        <h1 class="t-uppercase font-40">inquiry</h1>
                        <div class="col-lg-6 ptb-40">
                            <div align="center">
                                <form action="inc/inquiry_controller.php" method="post" enctype="multipart/form-data" >
                                    <div class="row row-tb-10 row-rl-10">
                                        <div class="col-md-12">
                                            <input class="form-control input-lg text" placeholder="Name" name="name" id="name">
                                        </div>
                                        <div class="col-md-12">
                                            <input class="form-control input-lg text" placeholder="email" name="email" id="email">
                                        </div>
                                         <div class="col-md-12">
                                            <input class="form-control input-lg field-date" placeholder=" Date" name="date">
                                        </div>
                                        <div class="col-md-12">
                                            <input class="form-control input-lg" placeholder="Phone Number" name="phone">
                                        </div>

                                        <div class="col-xs-12">
                                            <textarea class="form-control input-lg" rows="7" placeholder="Message" name="message" id="appointmentMessage"></textarea>
                                        </div>
                                        <div class="col-xs-12">
                                            <button class="btn btn-lg btn-block" type="submit" id="submit" name="submit">Submit</button>
                                        </div>
                                        <div class="col-xs-12">
                                            <div id="appointmentResponse" class="form-response">
                                                
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section><br/><br/>
            <!-- Start appointment Area -->
            <!-- Start Testimonial Area -->
           
            <!-- End Testimonial Area -->

		</main>
		<!-- –––––––––––––––[ END PAGE CONTENT ]––––––––––––––– -->

		<!-- –––––––––––––––[ FOOTER ]––––––––––––––– -->
		<?php include './inc/footer.php';?>