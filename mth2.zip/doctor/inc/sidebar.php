        <div class="col-sm-2 col-lg-2">
            <div class="sidebar-nav">
                <div class="nav-canvas">
                    <div class="nav-sm nav nav-stacked">

                    </div>
                    <ul class="nav nav-pills nav-stacked main-menu">
                        <li class="nav-header">Main</li>
                        <li><a class="ajax-link" href="dashboard.php"><span> Dashboard</span></a>
                        </li>
                        <li><a class="ajax-link" href="appointement.php"><span>View Appointement</span></a>
                        </li>
                        <li><a class="ajax-link" href="inquiry.php"><span>inquiry</span></a></li>
                        <li><a class="ajax-link" href="history.php"><span>History</span></a>
                        </li>
                        <li><a class="ajax-link" href="feedback.php"><span>Feedback</span></a>
                        </li>
                        <!--<li><a class="ajax-link" href="editprofile.php"><span>Edit Profile</span></a></li>-->
                        
                        <li class="dropdown open">
                            
                            <li class="accordion">
                            <a href="#"><span>Prescription</span></a>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="presform.php">Add prescription</a></li>
                                <li><a href="prescription.php">View Prescription</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
               
        
            </div>
        </div>
        <!--/span-->
        <!-- left menu ends -->
