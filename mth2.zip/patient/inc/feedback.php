<?php
    include 'model.php';
    $model=new model();

    include 'connect.php';
    $obj=new connect();
    $con=$obj->get_connect();
     session_start();
    if(isset($_POST))
    {
        $fname=$_REQUEST["fname"];
        $lname=$_REQUEST["lname"];
        $email=$_REQUEST["email"];
        $feedback=$_REQUEST["message"];

        $data=array(
            "patient_id"=>$_SESSION["puserid"],
            "fname"=>$fname,
            "lname"=>$lname,
            "email"=>$email,
            "feedback"=>$feedback
            );
        $result=$model->insert($con,"feedback",$data);

    }
header("Location: ../feedback.php");
?>