<?php include './inc/header.php';
$rr = $con->query("SELECT * FROM `registration` WHERE `id` = '".$_SESSION["puserid"]."' LIMIT 1")->fetch_assoc();
?>        <!-- –––––––––––––––[ HEADER ]––––––––––––––– -->

		<!-- –––––––––––––––[ PAGE CONTENT ]––––––––––––––– -->
		<main id="mainContent" class="main-content">
			<!-- Start Hero Area -->
			<section class="section breadcrumb-area pt-100 pb-80" data-bg-img="assets/images/slider/01.jpg">
                <div class="container t-center">
	            	<div class="row">
		            	<div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
							<div class="section-top-title">
								<h1 class="t-uppercase font-45">Your Feedback</h1>
								<ol class="breadcrumb">
								  <li><a href="index.php"><i class="fa fa-home mr-10"></i>Home</a></li>
								  <li class="active">Feedback</li>
								</ol>
							</div>
						</div>
					</div>
				</div>
            </section>
            <!-- End Hero Area -->

            <!-- Start appointment Area -->
            <section class="section appointment-area pt-60">
                <div class="container">
                    <div class="row mb-30">
                        <div class="col-lg-7 col-md-8 col-sm-10 col-xs-12 col-xs-center t-center mb-40">
                            <h6 class="section-subtitle mb-10 t-uppercase color-mid">WHY WE DO</h6>
                            <h2 class="section-title mb-20 font-22 t-uppercase">Your feedback</h2>
                            <div class="heart-line">
                                <img src="assets/images/icon.png" alt="Awesome Image">
                            </div>
                        </div>
                    </div>
                    <div class="row services">
                        <div class="col-lg-6">
                            <img src="assets/images/appointment/img-01.png" alt="">
                        </div>
                        <div class="col-lg-6 ptb-40">
                            <div class="appointment-form">
                                <form action="inc/feedback.php" method="post" enctype="multipart/form-data">
                                    <div class="row row-tb-10 row-rl-10">
                                        <div class="col-md-6">
                                            <input type="text" class="form-control input-lg" placeholder="Name" name="fname" value="<?php echo $rr["fname"]; ?>">
                                        </div>
                                        <div class="col-md-6">
                                            <input type="text" class="form-control input-lg" placeholder="Name" name="lname" value="<?php echo $rr["lname"]; ?>">
                                        </div>
                                        
                                        <div class="col-md-12">
                                            <input class="form-control input-lg" placeholder="Email" name="email" value="<?php echo $rr["email"]; ?>">
                                        </div>
                                        
                                        <div class="col-xs-12">
                                            <textarea class="form-control input-lg" rows="7" placeholder="Feedback" name="message" id="appointmentMessage"></textarea>
                                        </div>
                                        <div class="col-xs-12">
                                            <button class="btn btn-lg btn-block" type="submit" id="appointmentSubmit">Submit</button>
                                        </div>
                                        <div class="col-xs-12">
                                            <div id="appointmentResponse" class="form-response">
                                                
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Start appointment Area -->
            <!-- Start Testimonial Area -->
            
            <!-- End Testimonial Area -->

		</main>
		<!-- –––––––––––––––[ END PAGE CONTENT ]––––––––––––––– -->

		<!-- –––––––––––––––[ FOOTER ]––––––––––––––– -->
		<?php include './inc/footer.php';?>