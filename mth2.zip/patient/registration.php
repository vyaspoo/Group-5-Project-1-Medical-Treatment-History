
  
<!-- –––––––––––––––[ HEADER ]––––––––––––––– -->
<?php include '../doctor/inc/rcontroller.php';?>
<!-- 

Template Name: iMedical - Medical, Doctor, Dentist, Clinic and Hospital Template
Version: 1.0.0
Author: CODASTROID
Contact: codastroid@gmail.com
Follow: https://themeforest.net/user/codastroid?ref=codastroid
Template Link: https://themeforest.net/item/health-medical-dentist-doctor-clinic-and-hospital-template-imedical/19747019?ref=CODASTROID
License: You must have a valid license purchased only from themeforest in order to legally use the theme for your project.

-->

<!DOCTYPE html>
<!--[if lt IE 9 ]><html lang="en" dir="ltr" class="no-js ie-old"> <![endif]-->
<!--[if IE 9 ]><html lang="en" dir="ltr" class="no-js ie9"> <![endif]-->
<!--[if IE 10 ]><html lang="en" dir="ltr" class="no-js ie10"> <![endif]-->
<!--[if (gt IE 10)|!(IE)]><!-->
<html lang="en" dir="ltr" class="no-js">
<!--<![endif]-->


<!-- Mirrored from imedical-theme.firebaseapp.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 16 Jan 2018 07:53:55 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- META TAGS                                 -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <meta charset="utf-8">
    <!-- Always force latest IE rendering engine -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Mobile specific meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags --> 

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- PAGE TITLE                                -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <title>Medical treatement History</title>

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- SEO METAS                                 -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <meta name="description" content="brief description here">
    <meta name="keywords" content="insert, keywords, here">
    <meta name="robots" content="index, follow">
    <meta name="author" content="EvenThemes">

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- PAGE FAVICON                              -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <link rel="icon" type="image/icon" href="assets/images/favicon/favicon.png">

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- GOOGLE FONTS                              -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <link href="https://fonts.googleapis.com/css?family=Dosis:600,700" rel="stylesheet"> 
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:600,700' rel='stylesheet' type='text/css'>


    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- Include CSS Filess                        -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->

    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">

    <!-- Linearicons -->
    <link href="assets/vendors/linearicons/css/linearicons.css" rel="stylesheet">

    <!-- Webfont Medical Icons -->
    <link href="assets/vendors/webfont-medical-icons/css/wfmi-style.css" rel="stylesheet">

    <!-- Owl Carousel -->
    <link href="assets/vendors/owl-carousel/owl.carousel.min.css" rel="stylesheet">
    <link href="assets/vendors/owl-carousel/owl.theme.min.css" rel="stylesheet">

    <!-- Magnific popup -->
    <link href="assets/vendors/magnific-popup/css/magnific-popup.css" rel="stylesheet">

    <!-- YTPlayer -->
    <link href="assets/vendors/YTPlayer/css/jquery.mb.YTPlayer.min.css" rel="stylesheet">

    <!-- Bootstrap Datepicker -->
    <link rel="stylesheet" type="text/css" href="assets/vendors/bootstrap-datepicker/css/bootstrap.datepicker.css">


    <!-- Template Stylesheet -->
    <link href="assets/css/base.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/demo.css" rel="stylesheet">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
 $(function() {
        $( "#datepicker" ).datepicker({
            dateFormat : 'mm/dd/yy',
            changeMonth : true,
            changeYear : true,
            yearRange: '-100y:c+nn',
            maxDate: '-1d'
        });
    });
  </script>
   <script>      
        function test()
        {
                var count=0;
                var name=document.getElementById("fname").value;
                var name1=/^[a-zA-Z]{5,10}$/;
                if(name==''){
                    document.getElementById("error").innerHTML="please fill the blank";
                    count++;
                }
                else if(!name1.test(name)){
                    document.getElementById("error").innerHTML="invalid name";
                    count++;
                }
                else{
                    document.getElementById("error").innerHTML=""; 
                }
                var lname=document.getElementById("lname").value;
                var name1=/^[a-zA-Z]{5,10}$/;
                if(lname==''){
                    document.getElementById("error1").innerHTML="please fill the blank";
                    count++;
                }
                else if(!name1.test(lname)){
                    document.getElementById("error1").innerHTML="invalid name";
                    count++;
                }
                else{
                    document.getElementById("error1").innerHTML=""; 
                }
                 var gen= document.getElementById("gender").value;
                 if(gen==''){
                    document.getElementById("error2").innerHTML="please check one";
                    count++;
                }
                else{
                     document.getElementById("error2").innerHTML="";
                }
                var date=document.getElementById("datepicker").value;
                
                if(date==''){
                    document.getElementById("error3").innerHTML="please fill the blank";
                    count++;
                }
                
                else{
                    document.getElementById("error3").innerHTML=""; 
                } 

                
                var email=document.getElementById("email").value;
                 var email1=/^[a-zA-Z0-9]+@[a-zA-Z]+\.[a-zA-Z]{2,3}$/;
                
                if(email=='')
                {
                    document.getElementById("error4").innerHTML="please fill the blank";
                     count++;
                }
                else if(!email1.test(email)){
                    document.getElementById("error4").innerHTML="invalid email";
                     count++;
                }
                else{
                    document.getElementById("error4").innerHTML=""; 
                }
                var contact=document.getElementById("contact").value;
                var contact1=/^[0-9]{10}$/;
                if(contact==''){
                    document.getElementById("error5").innerHTML="please fill the blank";
                    count++;
                }
                else if(!contact1.test(contact)){
                    document.getElementById("error5").innerHTML="invalid name";
                    count++;
                }
                else{
                    document.getElementById("error5").innerHTML=""; 
                }
                 
                var add= document.getElementById("address").value;
                if(add==''){
                    document.getElementById("error6").innerHTML="please fill the blank";
                     count++;
                }
                else{
                     document.getElementById("error6").innerHTML="";
                }
                 
                  var roll= document.getElementById("roll").value;
                 if(roll==''){
                    document.getElementById("error9").innerHTML="please check one";
                    count++;
                }
                else{
                     document.getElementById("error9").innerHTML="";
                }
                var uname=document.getElementById("username").value;
                var uname1=/^[a-zA-Z]{6,16}$/;
                if(uname==''){
                    document.getElementById("error10").innerHTML="please fill the blank";
                    count++;
                }
                else if(!uname1.test(uname)){
                    document.getElementById("error10").innerHTML="invalid name";
                    count++;
                }
                else{
                    document.getElementById("error10").innerHTML=""; 
                }
                var pwd=document.getElementById("password").value;
                var pwd1=/^[a-zA-Z]{5,10}$/;
                if(pwd==''){
                    document.getElementById("error11").innerHTML="please fill the blank";
                    count++;
                }
                else if(!pwd1.test(pwd)){
                    document.getElementById("error11").innerHTML="invalid password";
                    count++;
                }
                else{
                    document.getElementById("error11").innerHTML=""; 
                }
                var education=document.getElementById("edu").value;
                if(education==''){
                    document.getElementById("error12").innerHTML="please fill the blank";
                    count++;
                }
                else{
                    document.getElementById("error12").innerHTML=""; 
                }
                var exp=document.getElementById("exp").value;
                if(exp==''){
                    document.getElementById("error13").innerHTML="please fill the blank";
                    count++;
                }
                else{
                    document.getElementById("error13").innerHTML=""; 
                }
                var sp=document.getElementById("sp").value;
                if(sp==''){
                    document.getElementById("error14").innerHTML="please fill the blank";
                    count++;
                }
                else{
                    document.getElementById("error14").innerHTML=""; 
                }
               
                if(count>0){
                    return false;
                }
        }
        function role_fn(){
            
              var roll= $("#roll").val();
              if(roll==0)
              {
                  document.getElementById("doctor").style.display='';
              }
              else
              {
                  document.getElementById("doctor").style.display='none';
              }
         
        }
    </script>
    

</head>
<body id="body" class="wide-layout preloader-active">

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- PRELOADER                                 -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- Preloader -->
    <div id="preloader" class="preloader">
        <div class="loader pos-center">
            
            <img src="assets/images/preloader.gif" alt="">
        </div>
    </div>
    <!-- End Preloader -->
    <div class="topbar bg-theme">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <ul class="topbar-info list-inline is-hidden-xs t-xs-center t-md-left">
                            <li class="prl-10">
                            <i class="fa fa-map-marker mr-10 font-16"></i>Apollo Institute of Technology,Anasan.</li>
                            <li class="prl-10">
                            <i class="fa fa-phone mr-10 font-16"></i> +91 7041112075 </li>
                            <li class="prl-10">
                            <i class="fa fa-envelope mr-10 font-16"></i>mth@gmail.com</li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <ul class="social-icons list-inline font-16  t-xs-center t-md-right is-hidden-sm">
                            <li class="social-icons__item"><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li class="social-icons__item"><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li class="social-icons__item"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li class="social-icons__item"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li class="social-icons__item"><a href="#"><i class="fa fa-pinterest"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- WRAPPER                                   -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
   <!-- –––––––––––––––[ HEADER ]––––––––––––––– -->
   <!-- –––––––––––––––[ HEADER ]––––––––––––––– -->

		<!-- –––––––––––––––[ PAGE CONTENT ]––––––––––––––– -->
		<main id="mainContent" class="main-content">
			<!-- Start Hero Area -->
			
            <!-- End Hero Area -->

            <!-- Start appointment Area -->
            <section class="section appointment-area pt-60">
                <div class="container" >
                     <div class="row mb-30">
                        <div class="col-lg-7 col-md-8 col-sm-10 col-xs-12 col-xs-center t-center mb-40">
                           <h2 class="section-title mb-20 font-22 t-uppercase">Registration</h2>
                            <div class="heart-line">
                                <img src="assets/images/icon.png" alt="Awesome Image">
                            </div>
                        </div>
                    </div>
                    
                        <div class="col-lg-9 ptb-40">
                            <div class="appointment-form">
                                <form action="" method="post" style="position:relative;bottom:90px;margin-left:30%;">
                                    <div class="row row-tb-10 row-rl-10">
                                        <div class="col-md-6">
                                            <input type="text" class="form-control input-lg" placeholder="First Name" name="fname" id="fname">
                                            <b id="error"></b>
                                        </div>
                                         <div class="col-md-6">
                                            <input type="text" class="form-control input-lg" placeholder="Last Name" name="lname" id="lname">
                                             <b id="error1"></b>
                                        </div>
                                         <div class="col-md-6">
                                            
                                             <select class="form-control"id="gender" name="gender" placeholder="select Gender">
                                                 <option value="">select Gender</option>
                                                                <option value="male">Male</option>
                                                                <option value="female">Female</option>
							</select>
                                             <b id="error2"></b>
                                        </div>
                                        <div class="col-md-6">
                                            <input type="text" id="datepicker" class="form-control" placeholder="DOB" name="datepicker">
                                             <b id="error3"></b>
                                        </div>
                                        <div class="col-md-6">
                                            <input type="text" class="form-control input-lg" placeholder="Email" name="email" id="email">
                                            <b id="error4"></b>
                                        </div>
                                        <div class="col-md-6">
                                            <input type="text" class="form-control input-lg" placeholder="Contact" name="contact" id="contact">
                                            <b id="error5"></b>
                                        </div>
                                        <div class="col-md-6">
                                            <textarea class="form-control input-lg" placeholder="Address" name="address" id="address" rows="7.8" cols="3"></textarea>
                                            <b id="error6"></b>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <select class="form-control" id="city" name="city">
                                                <option value="">Select city</option>
							 <?php foreach ($cityresult as $cat) {
                               ?>
                                        <option value="<?php echo $cat->city_id;?>"><?php echo $cat->city_name;?></option>
                                        <?php
                                        }?>
                                                            </select>
						<b id="error7"></b>
                                        </div>
                                        <div class="col-md-6">
                                            
                                
                                <select class="form-control" id="state" name="state">
                                    <option value="">Select state</option>
                                     <?php foreach ($allresult as $cat) {
                               ?>
                            <option value="<?php echo $cat->state_id;?>"><?php echo $cat->state_name;?></option>
                            <?php
                            }?>
                           
                                </select>
						<b id="error8"></b>
                                        </div>
                                        <div class="col-md-6">
                                            <select class="form-control" id="roll" name="roll" onchange="return role_fn();">
                                                <option value=""> Select Roll</option>
                                                <option value="0">doctor</option>
                                                <option value="1">patient</option>
                                             </select>
                                            <b id="error9"></b>
                                         </div>
                                         <div class="col-md-6">
                                            <input type="text" class="form-control input-lg" placeholder="Password" name="password" id="password">
                                            <b id="error10"></b>
                                        </div>
                                        <div class="col-md-6">
                                            <input type="text" class="form-control input-lg" placeholder="Username" name="username" id="uname">
                                            <b id="error11"></b>
                                        </div>
                                        <div class="row row-tb-10 row-rl-10" id="doctor" style="display: none;">
                                         <div class="col-md-6">
                                            <input type="text" class="form-control input-lg" placeholder="Education" name="edu" id="edu">
                                            <b id="error12"></b>
                                        </div>
                                         <div class="col-md-6">
                                            <input type="text" class="form-control input-lg" placeholder="Expireance" name="exp" id="exp">
                                            <b id="error13"></b>
                                        </div>
                                         <div class="col-md-12">
                                            <input type="text" class="form-control input-lg" placeholder="Speciality" name="sp" id="sp">
                                            <b id="error14"></b>
                                         </div>
                                        </div>
                                        <div class="col-xs-12">
                                            <input class="btn btn-lg btn-block" type="submit" name="register" id="register" onclick="return test()"></button><br/>
                                             
                                        </div>
                                        
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Start appointment Area -->
            <!-- Start Testimonial Area -->
          
            <!-- End Testimonial Area -->

		</main>
		<!-- –––––––––––––––[ END PAGE CONTENT ]––––––––––––––– -->

		<!-- –––––––––––––––[ FOOTER ]––––––––––––––– -->

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- END WRAPPER                               -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->

<footer class="main-footer pt-">
                    
            <div class="sub-footer">
                <div class="container">
                    <h6 class="copyright"> apollo © Copyright 2017. All rights reserved. </h6>
                </div>
            </div>
        </footer>
        <!-- –––––––––––––––[ END FOOTER ]––––––––––– -->

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- END WRAPPER                               -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->


    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- BACK TO TOP                               -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
       <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- SCRIPTS                                   -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->

    <!-- (!) Placed at the end of the document so the pages load faster -->

    <!-- =========[ jQuery library ]========= -->
    <script src="assets/js/jquery-1.12.3.min.js"></script>

    <!-- ========[ Latest Bootstrap ]======== -->
    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>

    <!-- ========[ JavaScript Plugins ]======== -->
    <!-- (!) Include all compiled plugins (below), or include individual files as needed -->

    <!-- Owl Carousel -->
    <script type="text/javascript" src="assets/vendors/owl-carousel/owl.carousel.min.js"></script>

    <!-- Magnific popup -->
    <script type="text/javascript" src="assets/vendors/magnific-popup/js/jquery.magnific-popup.min.js"></script>

    <!-- jQuery Easing v1.3 -->
    <script type="text/javascript" src="assets/vendors/jquery.easing.1.3.min.js"></script>

    <!-- MixItUp v2.1.11 -->
    <script type="text/javascript" src="assets/vendors/jquery.mixitup.js"></script>

    <!-- Bootstrap Datepicker -->
    <script type="text/javascript" src="assets/vendors/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>

    <!-- YTPlayer -->
    <script type="text/javascript" src="assets/vendors/YTPlayer/js/jquery.mb.YTPlayer.min.js"></script>

    <!-- =====[ Custom Template JavaScript ]===== -->
    <script type="text/javascript" src="assets/js/main.js"></script>
    <script type="text/javascript" src="assets/js/demo.js"></script>
</body>


<!-- Mirrored from imedical-theme.firebaseapp.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 16 Jan 2018 07:54:24 GMT -->
</html>