<?php include './inc/header.php';
 //include './inc/rcontoller.php';
?>

<!-- –––––––––––––––[ PAGE CONTENT ]––––––––––––––– -->
<main id="mainContent" class="main-content">


    <!-- Start Hero Area -->
    <section class="section breadcrumb-area pt-100 pb-80" data-bg-img="assets/images/slider/01.jpg">
        <div class="container t-center">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
                    <div class="section-top-title">
                        <h1 class="t-uppercase font-45">OUR DOCTORS</h1>
                        <ol class="breadcrumb">
                            <li><a href="index-3.html"><i class="fa fa-home mr-10"></i>Home</a></li>
                            <li class="active">Our doctors</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Hero Area -->
    <br/>
    
    <div class="row">
        <div class="col-lg-3"></div>
        <div class="col-lg-6">
    <form action="" method="post">
        <select name="search" plaseholder="Search Doctor.." id="doctor" name="doctor" style="width: 40%; height: 40px;"><option>Select Doctor</option>
             <?php foreach ($doctor as $cat) {
                               ?>
                            <option value="<?php echo $cat->id;?>"><?php echo $cat->fname;?></option>
                            <?php
                            }?>
                           
        </select>
        
        <select name="search" placeholder="Search Doctor.." name="city" style="width: 40%; height: 40px;"><option>Select City</option>
         <?php foreach ($cityresult as $cat) {
                               ?>
                            <option value="<?php echo $cat->id;?>"><?php echo $cat->city_name;?></option>
                            <?php
                            }?>
        </select>
             <button class="btn" type="submit" id="search" name="search">Search</button></select>
    </form>
            
    </div>
        
    </div>
    
    <section class="doctors-area doctors-list ptb-80">
        <div class="container">
            <div class="row pb-60">
                <div class="col-lg-4 col-md-5 ptb-10">
                    <figure class="embed-responsive embed-responsive-4by3 bg-ct" data-bg-img="images/doctor.jpg"></figure>
                </div>
                <div class="col-lg-8 col-md-7 ptb-10">
                    <h3 class="t-uppercase">
                        <a href="team-single.html">DR.Ruhani</a>
                    </h3>
                    <h5 class="mb-15 color-theme">Doctor</h5>
                    <ul class="social-icons list-inline font-16 mb-20">
                        <li class="social-icons__item"><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li class="social-icons__item"><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li class="social-icons__item"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li class="social-icons__item"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li class="social-icons__item"><a href="#"><i class="fa fa-pinterest"></i></a></li>
                    </ul>
                    <p class="color-mid mb-20">Competently customize bricks-and-clicks core Competently customize bricks-and-clicks core competencies with adaptive leadership skills. Competently maintain intermandated. competencies with adaptive leadership skills. Competently maintain intermandated.</p>
                    
                     <a href="doctor.php" class="btn btn-o btn-rounded">View More</a>
                </div>
            </div>
            <div class="row pb-60">
                <div class="col-lg-4 col-md-5 ptb-10">
                    <figure class="embed-responsive embed-responsive-4by3 bg-ct" data-bg-img="images/doctor.jpg"></figure>
                </div>
                <div class="col-lg-8 col-md-7 ptb-10">
                    <h3 class="t-uppercase">
                        <a href="team-single.html">Dr.Reshma</a>
                    </h3>
                    <h5 class="mb-15 color-theme">Doctor</h5>
                    <ul class="social-icons list-inline font-16 mb-20">
                        <li class="social-icons__item"><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li class="social-icons__item"><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li class="social-icons__item"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li class="social-icons__item"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li class="social-icons__item"><a href="#"><i class="fa fa-pinterest"></i></a></li>
                    </ul>
                    <p class="color-mid mb-20">Competently customize bricks-and-clicks core Competently customize bricks-and-clicks core competencies with adaptive leadership skills. Competently maintain intermandated. competencies with adaptive leadership skills. Competently maintain intermandated.</p>
                    
                     <a href="doctor.php" class="btn btn-o btn-rounded">View More</a>
                </div>
            </div>
            <div class="row pb-60">
                <div class="col-lg-4 col-md-5 ptb-10">
                    <figure class="embed-responsive embed-responsive-4by3 bg-ct" data-bg-img="images/doctor.jpg"></figure>
                </div>
                <div class="col-lg-8 col-md-7 ptb-10">
                    <h3 class="t-uppercase">
                        <a href="team-single.html">Dr.Mehta</a>
                    </h3>
                    <h5 class="mb-15 color-theme">Doctor</h5>
                    <ul class="social-icons list-inline font-16 mb-20">
                        <li class="social-icons__item"><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li class="social-icons__item"><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li class="social-icons__item"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li class="social-icons__item"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li class="social-icons__item"><a href="#"><i class="fa fa-pinterest"></i></a></li>
                    </ul>
                    <p class="color-mid mb-20">Competently customize bricks-and-clicks core Competently customize bricks-and-clicks core competencies with adaptive leadership skills. Competently maintain intermandated. competencies with adaptive leadership skills. Competently maintain intermandated.</p>
                    
                     <a href="doctor.php" class="btn btn-o btn-rounded">View More</a>
                </div>
            </div>
            <div class="row pb-60">
                <div class="col-lg-4 col-md-5 ptb-10">
                    <figure class="embed-responsive embed-responsive-4by3 bg-ct" data-bg-img="images/doctor.jpg"></figure>
                </div>
                <div class="col-lg-8 col-md-7 ptb-10">
                    <h3 class="t-uppercase">
                        <a href="team-single.html">Dr.Shah</a>
                    </h3>
                    <h5 class="mb-15 color-theme">Doctor</h5>
                    <ul class="social-icons list-inline font-16 mb-20">
                        <li class="social-icons__item"><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li class="social-icons__item"><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li class="social-icons__item"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li class="social-icons__item"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li class="social-icons__item"><a href="#"><i class="fa fa-pinterest"></i></a></li>
                    </ul>
                    <p class="color-mid mb-20">Competently customize bricks-and-clicks core Competently customize bricks-and-clicks core competencies with adaptive leadership skills. Competently maintain intermandated. competencies with adaptive leadership skills. Competently maintain intermandated.</p>
                    
                    
                    <a href="doctor.php" class="btn btn-o btn-rounded">View More</a>
                </div>
            </div>
            <div class="view-more t-center">
                <a href="#" class="btn btn-lg btn-rounded">View More</a>
                
            </div>
        </div>
    </section>




</main>
<!-- –––––––––––––––[ END PAGE CONTENT ]––––––––––––––– -->

<?php include './inc/footer.php'; ?>