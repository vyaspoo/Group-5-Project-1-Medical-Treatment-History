<?php include './inc/header.php';?>        <!-- –––––––––––––––[ HEADER ]––––––––––––––– -->

		<!-- –––––––––––––––[ PAGE CONTENT ]––––––––––––––– -->
		<main id="mainContent" class="main-content">

			<!-- Start Hero Area -->
            <section class="section breadcrumb-area pt-100 pb-80" data-bg-img="assets/images/slider/01.jpg">
                <div class="container t-center">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
                            <div class="section-top-title">
                                <h1 class="t-uppercase font-45">Testimonials</h1>
                                <ol class="breadcrumb">
                                    <li><a href="index.php"><i class="fa fa-home mr-10"></i>Home</a></li>
                                    <li class="active">Testimonials</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- End Hero Area -->

            <!-- Start Testimonials Area -->
            <section class="section testimonials-area testimonials-area-5 ptb-60">
                <div class="container">
                    <div class="row mb-30">
                        <div class="col-lg-7 col-md-8 col-sm-10 col-xs-12 col-xs-center t-center mb-40">
                            <h6 class="section-subtitle mb-10 t-uppercase color-mid">Testimonials</h6>
                            <h2 class="section-title mb-20 font-22 t-uppercase">our Awesome clients</h2>
                            <div class="heart-line">
                                <img src="assets/images/icon.png" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="row row-tb-15">
                        <div class="col-md-6">
                            <div class="testimonial-panel">
                                <div class="testimonial-body">
                                    <p class="testimonial-content mb-20">Phasellus pretium orci sit amet mi ullamcorper egestas. Sed non mattis metus. Integer vel lorem tincidunt, pharetra eros nec, posuere odio. Nullam eget bibendum sem, venenatis lacinia justo.</p>
                                    <div class="testimonial-meta">
                                        <div class="testimonial-img">
                                            <img src="assets/images/testimonial/01.jpg" alt="Testimonial Author">
                                        </div>
                                        <h5 class="ptb-5 t-uppercase color-theme">John Doe</h5>
                                        <h6 class="mb-0 color-mid">Ceo & Founder</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="testimonial-panel">
                                <div class="testimonial-body">
                                    <p class="testimonial-content mb-20">Phasellus pretium orci sit amet mi ullamcorper egestas. Sed non mattis metus. Integer vel lorem tincidunt, pharetra eros nec, posuere odio. Nullam eget bibendum sem, venenatis lacinia justo.</p>
                                    <div class="testimonial-meta">
                                        <div class="testimonial-img">
                                            <img src="assets/images/testimonial/02.jpg" alt="Testimonial Author">
                                        </div>
                                        <h5 class="ptb-5 t-uppercase color-theme">John Doe</h5>
                                        <h6 class="mb-0 color-mid">Ceo & Founder</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="testimonial-panel">
                                <div class="testimonial-body">
                                    <p class="testimonial-content mb-20">Phasellus pretium orci sit amet mi ullamcorper egestas. Sed non mattis metus. Integer vel lorem tincidunt, pharetra eros nec, posuere odio. Nullam eget bibendum sem, venenatis lacinia justo.</p>
                                    <div class="testimonial-meta">
                                        <div class="testimonial-img">
                                            <img src="assets/images/testimonial/03.jpg" alt="Testimonial Author">
                                        </div>
                                        <h5 class="ptb-5 t-uppercase color-theme">John Doe</h5>
                                        <h6 class="mb-0 color-mid">Ceo & Founder</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="testimonial-panel">
                                <div class="testimonial-body">
                                    <p class="testimonial-content mb-20">Phasellus pretium orci sit amet mi ullamcorper egestas. Sed non mattis metus. Integer vel lorem tincidunt, pharetra eros nec, posuere odio. Nullam eget bibendum sem, venenatis lacinia justo.</p>
                                    <div class="testimonial-meta">
                                        <div class="testimonial-img">
                                            <img src="assets/images/testimonial/03.jpg" alt="Testimonial Author">
                                        </div>
                                        <h5 class="ptb-5 t-uppercase color-theme">John Doe</h5>
                                        <h6 class="mb-0 color-mid">Ceo & Founder</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- End Testimonials Area -->            <!-- Start Testimonials Area -->
           
            <!-- End Testimonials Area -->            <!-- Start Testimonials Area 1 -->
            
            <!-- End Testimonials Area 1 -->            <!-- Start Testimonial Area -->
            <section class="section testimonials-area testimonials-area-3 ptb-60 bg-gray">
                <div class="container">
                    <div class="row mb-40">
                        <div class="col-lg-7 col-md-8 col-sm-10 col-xs-12 col-xs-center t-center">
                            <h6 class="section-subtitle mb-10 t-uppercase color-mid">What our client says about us</h6>
                            <h2 class="section-title mb-20 font-22 t-uppercase">Our Happy Client</h2>
                            <div class="heart-line">
                                <img src="assets/images/icon.png" alt="Awesome Image">
                            </div>
                        </div>
                    </div>

                    <!-- carousel start -->
                    <div class="testimonial-slider owl-carousel"
                    data-loop="true"
                    data-autoplay="false"
                    data-autoplay-timeout="10000"
                    data-smart-speed="1000"
                    data-nav-speed="false"
                    data-dots="false"
                    data-nav="false"
                    data-lg-nav="false"
                    data-md-nav="false"
                    data-sm-nav="false"
                    data-xs-nav="false"
                    data-xxs-nav="false"
                    data-lg-items="3"
                    data-md-items="3"
                    data-sm-items="2"
                    data-xs-items="1"
                    data-xxs-items="1">

                        <div class="item">
                            <div class="testimonial-single">
                                <p class="testimonial-content">Ut consequat eget nulla eu ultrices. Curabitur ac pellentesque mi, nec sagittis sem. Mauris sit amet odio interdum, aliquam purus a, dignissim neque.</p>
                                <div class="testimonial-info">
                                    <div class="testimonial-thumb">
                                        <img src="assets/images/testimonial/01.jpg" alt="">
                                    </div>
                                    <h6 class="t-uppercase">John Doe</h6>
                                    <span class="color-theme">Web Designer</span>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-single">
                                <p class="testimonial-content">Ut consequat eget nulla eu ultrices. Curabitur ac pellentesque mi, nec sagittis sem. Mauris sit amet odio interdum, aliquam purus a, dignissim neque.</p>
                                <div class="testimonial-info">
                                    <div class="testimonial-thumb">
                                        <img src="assets/images/testimonial/01.jpg" alt="">
                                    </div>
                                    <h6 class="t-uppercase">John Doe</h6>
                                    <span class="color-theme">Web Designer</span>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-single">
                                <p class="testimonial-content">Ut consequat eget nulla eu ultrices. Curabitur ac pellentesque mi, nec sagittis sem. Mauris sit amet odio interdum, aliquam purus a, dignissim neque.</p>
                                <div class="testimonial-info">
                                    <div class="testimonial-thumb">
                                        <img src="assets/images/testimonial/01.jpg" alt="">
                                    </div>
                                    <h6 class="t-uppercase">John Doe</h6>
                                    <span class="color-theme">Web Designer</span>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-single">
                                <p class="testimonial-content">Ut consequat eget nulla eu ultrices. Curabitur ac pellentesque mi, nec sagittis sem. Mauris sit amet odio interdum, aliquam purus a, dignissim neque.</p>
                                <div class="testimonial-info">
                                    <div class="testimonial-thumb">
                                        <img src="assets/images/testimonial/01.jpg" alt="">
                                    </div>
                                    <h6 class="t-uppercase">John Doe</h6>
                                    <span class="color-theme">Web Designer</span>
                                </div>
                            </div>
                        </div>

                    </div>
                    <!-- carousel end -->

                </div>
            </section>
            <!-- End Testimonial Area -->


		</main>
		<!-- –––––––––––––––[ END PAGE CONTENT ]––––––––––––––– -->

		<!-- –––––––––––––––[ FOOTER ]––––––––––––––– -->
		<?php include './inc/footer.php';?>