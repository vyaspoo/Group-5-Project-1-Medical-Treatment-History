
<?php include './inc/lcontroller.php';
$st = $_GET["st"];?>

<html lang="en" dir="ltr" class="no-js">
<!--<![endif]-->


<!-- Mirrored from imedical-theme.firebaseapp.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 16 Jan 2018 07:53:55 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- META TAGS                                 -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <meta charset="utf-8">
    <!-- Always force latest IE rendering engine -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Mobile specific meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags --> 

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- PAGE TITLE                                -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <title>iMedical - Medical, Doctor, Dentist, Clinic and Hospital Template</title>

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- SEO METAS                                 -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <meta name="description" content="brief description here">
    <meta name="keywords" content="insert, keywords, here">
    <meta name="robots" content="index, follow">
    <meta name="author" content="EvenThemes">

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- PAGE FAVICON                              -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <link rel="icon" type="image/icon" href="assets/images/favicon/favicon.png">

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- GOOGLE FONTS                              -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <link href="https://fonts.googleapis.com/css?family=Dosis:600,700" rel="stylesheet"> 
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:600,700' rel='stylesheet' type='text/css'>


    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- Include CSS Filess                        -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->

    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">

    <!-- Linearicons -->
    <link href="assets/vendors/linearicons/css/linearicons.css" rel="stylesheet">

    <!-- Webfont Medical Icons -->
    <link href="assets/vendors/webfont-medical-icons/css/wfmi-style.css" rel="stylesheet">

    <!-- Owl Carousel -->
    <link href="assets/vendors/owl-carousel/owl.carousel.min.css" rel="stylesheet">
    <link href="assets/vendors/owl-carousel/owl.theme.min.css" rel="stylesheet">

    <!-- Magnific popup -->
    <link href="assets/vendors/magnific-popup/css/magnific-popup.css" rel="stylesheet">

    <!-- YTPlayer -->
    <link href="assets/vendors/YTPlayer/css/jquery.mb.YTPlayer.min.css" rel="stylesheet">

    <!-- Bootstrap Datepicker -->
    <link rel="stylesheet" type="text/css" href="assets/vendors/bootstrap-datepicker/css/bootstrap.datepicker.css">


    <!-- Template Stylesheet -->
    <link href="assets/css/base.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/demo.css" rel="stylesheet">
    
</head>
<body id="body" class="wide-layout preloader-active">

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- PRELOADER                                 -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- Preloader -->
    <div id="preloader" class="preloader">
        <div class="loader pos-center">
            <img src="assets/images/preloader.gif" alt="">
        </div>
    </div>
    <!-- End Preloader -->

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- WRAPPER                                   -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <div id="pageWrapper" class="page-wrapper">
        
        <!-- –––––––––––––––[ HEADER ]––––––––––––––– -->
        <!-- Start Top Bar -->
        <div class="topbar bg-theme">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <ul class="topbar-info list-inline is-hidden-xs t-xs-center t-md-left">
                            <li class="prl-10">
                            <i class="fa fa-map-marker mr-10 font-16"></i>Apollo Institute,Anasan </li>
                            <li class="prl-10">
                            <i class="fa fa-phone mr-10 font-16"></i> +(91)9876543232</li>
                            <li class="prl-10">
                            <i class="fa fa-envelope mr-10 font-16"></i>MTH@gmail.com</li>
                           
                            
                            
                        </ul>
                        
                        </div>
                   
                     </div>
              
                </div>
            
                </div>   
                   
               
                
            
            

       

        
<!-- –––––––––––––––[ HEADER ]––––––––––––––– -->
		<!-- –––––––––––––––[ PAGE CONTENT ]––––––––––––––– -->
		<main id="mainContent" class="main-content">
			<!-- Start Hero Area -->
			
            <!-- End Hero Area -->

            <!-- Start appointment Area -->
            <section class="section appointment-area pt-60">
                <div class="container">
                     <div class="row mb-30">
                        <div class="col-lg-7 col-md-8 col-sm-10 col-xs-12 col-xs-center t-center mb-40">
                           <h2 class="section-title mb-20 font-22 t-uppercase">Login Here</h2>
                            <div class="heart-line">
                                <img src="assets/images/icon.png" alt="Awesome Image">
                            </div>
                        </div>
                    </div>
                    
                        <div class="col-lg-9 ptb-40">
                            <div class="appointment-form">
                                <form action="" method="post"  style="margin-left:300px;position:relative;bottom:80px;">
                                    <div class="row row-tb-10 row-rl-10">
                                        <?php if($st == 1){echo "<br><p style='text-align: center;'>Password sent in your mail. Please check you inbox.</p>";} ?>
                                        <div class="col-md-12">
                                            <input type="text" class="form-control input-lg" placeholder="User Name" name="username" id="appointmentFname">
                                        </div>
                                        <div class="col-md-12">
                                            <input type="password" class="form-control input-lg" placeholder="password" name="password" id="appointmentFname">
                                        </div>
                                        <div class="col-xs-12">
                                            <button class="btn btn-lg btn-block" type="submit" id="submit" name="submit">Submit</button><br/>
                                            <a href="registration.php">If you have not Registered</a> 
                                            <a style="float: right;" href="forgot.php">Forgot Password?</a>
                                        </div>
                                        
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Start appointment Area -->
            <!-- Start Testimonial Area -->
          
            <!-- End Testimonial Area -->

		</main>
		<!-- –––––––––––––––[ END PAGE CONTENT ]––––––––––––––– -->

		<!-- –––––––––––––––[ FOOTER ]––––––––––––––– -->
		<br/> </br> 
<footer class="main-footer ">
            
            <div class="sub-footer">
                <div class="container">
                    <h6 class="copyright"> MTH © Copyright 2018. All rights reserved. </h6>
                </div>
            </div>
        </footer>
        <!-- –––––––––––––––[ END FOOTER ]––––––––––– -->


    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- END WRAPPER                               -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->


    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- BACK TO TOP                               -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- SCRIPTS                                   -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->

    <!-- (!) Placed at the end of the document so the pages load faster -->

    <!-- =========[ jQuery library ]========= -->
    <script src="assets/js/jquery-1.12.3.min.js"></script>

    <!-- ========[ Latest Bootstrap ]======== -->
    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>

    <!-- ========[ JavaScript Plugins ]======== -->
    <!-- (!) Include all compiled plugins (below), or include individual files as needed -->

    <!-- Owl Carousel -->
    <script type="text/javascript" src="assets/vendors/owl-carousel/owl.carousel.min.js"></script>

    <!-- Magnific popup -->
    <script type="text/javascript" src="assets/vendors/magnific-popup/js/jquery.magnific-popup.min.js"></script>

    <!-- jQuery Easing v1.3 -->
    <script type="text/javascript" src="assets/vendors/jquery.easing.1.3.min.js"></script>

    <!-- MixItUp v2.1.11 -->
    <script type="text/javascript" src="assets/vendors/jquery.mixitup.js"></script>

    <!-- Bootstrap Datepicker -->
    <script type="text/javascript" src="assets/vendors/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>

    <!-- YTPlayer -->
    <script type="text/javascript" src="assets/vendors/YTPlayer/js/jquery.mb.YTPlayer.min.js"></script>

    <!-- =====[ Custom Template JavaScript ]===== -->
    <script type="text/javascript" src="assets/js/main.js"></script>
    <script type="text/javascript" src="assets/js/demo.js"></script>
</body>


<!-- Mirrored from imedical-theme.firebaseapp.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 16 Jan 2018 07:54:24 GMT -->
</html>