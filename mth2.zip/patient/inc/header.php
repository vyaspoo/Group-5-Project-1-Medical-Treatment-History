<?php
include 'inc/connect.php';
$obj=new connect();
$con=$obj->get_connect();
session_start();
if(isset($_SESSION["puserid"])){
$name =$_SESSION["name"];


}
?>
<!-- 

Template Name: iMedical - Medical, Doctor, Dentist, Clinic and Hospital Template
Version: 1.0.0
Author: CODASTROID
Contact: codastroid@gmail.com
Follow: https://themeforest.net/user/codastroid?ref=codastroid
Template Link: https://themeforest.net/item/health-medical-dentist-doctor-clinic-and-hospital-template-imedical/19747019?ref=CODASTROID
License: You must have a valid license purchased only from themeforest in order to legally use the theme for your project.

-->

<!DOCTYPE html>
<!--[if lt IE 9 ]><html lang="en" dir="ltr" class="no-js ie-old"> <![endif]-->
<!--[if IE 9 ]><html lang="en" dir="ltr" class="no-js ie9"> <![endif]-->
<!--[if IE 10 ]><html lang="en" dir="ltr" class="no-js ie10"> <![endif]-->
<!--[if (gt IE 10)|!(IE)]><!-->
<html lang="en" dir="ltr" class="no-js">
<!--<![endif]-->


<!-- Mirrored from imedical-theme.firebaseapp.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 16 Jan 2018 07:53:55 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- META TAGS                                 -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <meta charset="utf-8">
    <!-- Always force latest IE rendering engine -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Mobile specific meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags --> 

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- PAGE TITLE                                -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <title>Medical treatement History</title>

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- SEO METAS                                 -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <meta name="description" content="brief description here">
    <meta name="keywords" content="insert, keywords, here">
    <meta name="robots" content="index, follow">
    <meta name="author" content="EvenThemes">

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- PAGE FAVICON                              -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <link rel="icon" type="image/icon" href="assets/images/favicon/favicon.png">

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- GOOGLE FONTS                              -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <link href="https://fonts.googleapis.com/css?family=Dosis:600,700" rel="stylesheet"> 
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:600,700' rel='stylesheet' type='text/css'>


    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- Include CSS Filess                        -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->

    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">

    <!-- Linearicons -->
    <link href="assets/vendors/linearicons/css/linearicons.css" rel="stylesheet">

    <!-- Webfont Medical Icons -->
    <link href="assets/vendors/webfont-medical-icons/css/wfmi-style.css" rel="stylesheet">
    
    <!-- Owl Carousel -->
    <link href="assets/vendors/owl-carousel/owl.carousel.min.css" rel="stylesheet">
    <link href="assets/vendors/owl-carousel/owl.theme.min.css" rel="stylesheet">

    <!-- Magnific popup -->
    <link href="assets/vendors/magnific-popup/css/magnific-popup.css" rel="stylesheet">

    <!-- YTPlayer -->
    <link href="assets/vendors/YTPlayer/css/jquery.mb.YTPlayer.min.css" rel="stylesheet">

    <!-- Bootstrap Datepicker -->
    <link rel="stylesheet" type="text/css" href="assets/vendors/bootstrap-datepicker/css/bootstrap.datepicker.css">


    <!-- Template Stylesheet -->
    <link href="assets/css/base.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/demo.css" rel="stylesheet">
    
</head>
<body id="body" class="wide-layout preloader-active">

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- PRELOADER                                 -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- Preloader -->
    <div id="preloader" class="preloader">
        <div class="loader pos-center">
            <img src="assets/images/preloader.gif" alt="">
        </div>
    </div>
    <!-- End Preloader -->

    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <!-- WRAPPER                                   -->
    <!-- ––––––––––––––––––––––––––––––––––––––––– -->
    <div id="pageWrapper" class="page-wrapper">
        
        <!-- –––––––––––––––[ HEADER ]––––––––––––––– -->
        <!-- Start Top Bar -->
        <div class="topbar bg-theme">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <ul class="topbar-info list-inline is-hidden-xs t-xs-center t-md-left">
                            <li class="prl-10">
                            <i class="fa fa-map-marker mr-10 font-16"></i>Apollo Institute of Technology,Anasan.</li>
                            <li class="prl-10">
                            <i class="fa fa-phone mr-10 font-16"></i> +91 7041112075 </li>
                            <li class="prl-10">
                            <i class="fa fa-envelope mr-10 font-16"></i>mth@gmail.com</li>
                             
                        </ul>
                        
                    </div>
                    <div class="col-md-4">
                        
                        
                        <ul class="social-icons list-inline font-16  t-xs-center t-md-right is-hidden-sm">
                            <?php
                            if(isset($_SESSION["puserid"]))
                            {
                                ?>
                            <?php echo "welcome ".$name;?>
                            <li class="social-icons__item" ><a href="logout.php"><i class="fa fa-login"  style="width: 100px;">LogOut</i></a></li>
                            
                            
                                <?php
                            }
                            else {
                                    ?>
                                    <li class="social-icons__item" ><a href="login.php"><i class="fa fa-login"  style="width: 100px;">Login</i></a></li>
                                    
                                    <?php
                            }

                            ?>
                            
                            
                           
                           
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <header id="mainHeader" class="main-header">
            <div class="header-menu">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="logo">
                                <a href="index.php"><img src="assets/images/mylogo_1.png" alt=""> <b style="font-family:initial; font-size: 130%; color: #0099FF">Medical Treatement History</b></a>
                            </div>
                            <!-- Phone Menu button -->
                            <button id="menu" class="menu is-hidden-md-up"></button>
                        </div>
                        <div class="col-md-9" style="padding-right: 10%;">
                            <nav class="navigation">
                                  
                            <?php
                            if(isset($_SESSION["puserid"]))
                            {
                                ?>
                                <ul>
                                    <li><a href="index.php">Home</a></li>
                                        
                                    <li><a href="about.php">About us</a></li>
                                   
                                    
                                    
                                      <li><a href="services.php">Services</a> <i class="fa fa-plus is-hidden-md-up"></i>
                                        
                                    </li>
                                    <li><a href="javascript:avoid(0);">Doctors</a> <i class="fa fa-plus is-hidden-md-up"></i>
                                        <ul class="sub-nav">
                                            <li><a href="doctor1.php">Doctor Details</a> </li>
                                        </ul>
                                    </li>
                                    <li><a href="javascript:avoid(0);">Blog</a> <i class="fa fa-plus is-hidden-md-up"></i>
                                        <ul class="sub-nav">
                                            <li><a href="blog-single.php">Blog Details</a></li>
                                        </ul>
                                    </li>
                                   
                                    <li><a href="javascript:avoid(0);">pages</a> <i class="fa fa-plus is-hidden-md-up"></i>
                                        <ul class="sub-nav">
                                             <li> <a href="history.php">Your History</a> </li>
                                            <li> <a href="appointment.php">Appointment</a> </li>
                                            <li> <a href="gallery-02.php">Gallery</a></li>
                                            <li> <a href="departments.php">Departements</a></li>
                                             <li> <a href="testimonials.php">Testimonials</a> </li>
                                             <li> <a href="feedback.php">Feedback</a> </li>
                                        </ul>
                                    </li>
                                    <li><a href="contact-us.php">Contact us</a></li>
                            </ul>
                            
                                <?php
                            }
                            else {
                                    ?>
                                    <ul>
                                    <li><a href="index.php">Home</a>
                                        
                                    </li>
                                    <li><a href="about.php">About us</a></li>
                                        <li><a href="javascript:avoid(0);">Doctors</a> <i class="fa fa-plus is-hidden-md-up"></i>
                                            <ul class="sub-nav">
                                                <li><a href="doctor1.php">Doctor Details</a> </li>
                                            </ul>
                                        </li>
                                   
                                    <li><a href="contact-us.php">Contact us</a></li>
                                    
                                </ul>
                                    
                                    <?php
                            }

                            ?>
                                
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </header>
