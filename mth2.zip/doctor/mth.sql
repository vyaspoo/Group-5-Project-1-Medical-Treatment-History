-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2018 at 09:59 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mth`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointement`
--

CREATE TABLE IF NOT EXISTS `appointement` (
  `app_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `fname` varchar(10) NOT NULL,
  `lname` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(30) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `from_time` int(11) NOT NULL,
  `to_time` int(11) NOT NULL,
  `email` varchar(20) NOT NULL,
  `contact` bigint(12) NOT NULL,
  `doc_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `feedback_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `name` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `feedback` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE IF NOT EXISTS `prescription` (
  `pres_id` int(11) NOT NULL,
  `patient_name` varchar(20) NOT NULL,
  `pres_date` date NOT NULL,
  `prescription` varchar(40) NOT NULL,
  `symptoms` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`pres_id`, `patient_name`, `pres_date`, `prescription`, `symptoms`) VALUES
(1, 'helly', '2018-01-09', 'fever', 'fever'),
(3, 'avni', '2011-01-11', 'bsdvcvc', 'sgu'),
(7, 'pooja', '2012-03-12', 'kdvsvsc ', 'bvhvvc'),
(8, 'pooja', '2012-03-12', 'kdvsvsc ', 'bvhvvc'),
(9, 'sakshi', '0000-00-00', 'headache', 'fever'),
(10, 'krutika', '0000-00-00', 'diabetese', 'diabetese'),
(11, 'avni', '2011-01-11', 'fsaxxerrax', 'headache'),
(12, 'mrunali', '0000-00-00', 'jdjdbvhibwivbi', 'erwtgdfvxcsaew'),
(13, 'falguni', '0000-00-00', 'bcvfxreaswqcxb', 'rdfvxcsdwr'),
(14, '1', '0000-00-00', '', ''),
(15, '1', '0000-00-00', '', ''),
(16, 'falguni', '0000-00-00', 'bcvfxreaswqcxb', 'rdfvxcsdwr'),
(17, 'ma', '0000-00-00', '', ''),
(18, 'redttttt', '0000-00-00', '', ''),
(19, 'm', '0000-00-00', '', ''),
(20, 'm', '0000-00-00', '', ''),
(21, 'm', '0000-00-00', '', ''),
(22, 'm', '0000-00-00', '', ''),
(23, 'bhavna', '0000-00-00', 'kuvs vv', 'lvmkmvw'),
(24, 'bhavna', '0000-00-00', 'kuvs vv', 'lvmkmvw'),
(25, 'bhavna', '0000-00-00', 'kuvs vv', 'lvmkmvw'),
(26, 'bhavna', '0000-00-00', 'kuvs vv', 'lvmkmvw'),
(27, 'bhavna', '0000-00-00', 'kuvs vv', 'lvmkmvw'),
(28, 'bhavna', '0000-00-00', 'kuvs vv', 'lvmkmvw'),
(29, 'bhavna', '0000-00-00', 'kuvs vv', 'lvmkmvw'),
(30, 'bhavna', '0000-00-00', 'kuvs vv', 'lvmkmvw'),
(31, 'krutika', '0000-00-00', 'vhk vh', 'gfxtx'),
(32, 'krutika', '2018-03-07', 'vhk vh', 'gfxtx'),
(33, 'krutika', '2018-03-07', 'vhk vh', 'gfxtx'),
(34, 'krutika', '2018-03-07', 'vhk vh', 'gfxtx'),
(35, 'krutika', '2018-03-07', 'vhk vh', 'gfxtx'),
(36, 'krutika', '2018-03-07', 'vhk vh', 'gfxtx'),
(37, 'krutika', '2018-03-07', 'vhk vh', 'gfxtx'),
(38, '', '0000-00-00', 'nbvcvcxzasdc,', 'ygfdddddd'),
(39, '', '2018-03-21', 'nbvcvcxzasdc,', 'ygfdddddd'),
(40, 'helly', '2018-03-21', 'xtsjs', 'hgudud');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `id` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(16) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact` bigint(10) NOT NULL,
  `address` varchar(30) NOT NULL,
  `city` varchar(15) NOT NULL,
  `state` varchar(20) NOT NULL,
  `roll_id` varchar(25) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=219 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `fname`, `lname`, `dob`, `gender`, `email`, `contact`, `address`, `city`, `state`, `roll_id`, `username`, `password`) VALUES
(1, 'manali', 'patel', '0000-00-00', 'Male', 'mrunaligavare1997@gmail.com', 0, 'vgc', 'Ahmedabad', 'punjab', 'patient', 'helly', '1997'),
(2, 'bijal', 'patel', '1999-04-18', 'Female', 'mrunaligavare1997@gmail.com', 988766543, 'ihgfdsxcvv', 'Ahmedabad', 'gujrat', '', 'mrunali', '12345'),
(11, 'sakshi', 'gavare', '2000-01-11', 'Female', 's@gmail.com', 988776659, 'jdcywcdy', 'Baroda', 'gujrat', '', 'sakshi', '123'),
(13, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(14, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(15, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(16, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(17, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(18, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(19, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(20, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(21, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(22, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(23, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(24, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(25, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(26, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(27, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(28, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(29, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(30, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(31, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(32, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(33, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(34, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(35, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(36, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(37, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(38, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(39, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(40, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(41, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(42, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(43, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(44, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(45, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(46, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(47, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(48, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(49, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(50, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(51, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(52, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(53, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(54, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(55, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(56, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(57, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(58, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(59, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(60, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(61, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(62, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(63, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(64, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(65, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(66, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(67, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(68, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(69, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(70, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(71, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(72, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(73, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(74, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(75, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(76, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(77, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(78, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(79, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(80, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(81, 'manali', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(82, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(83, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(84, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(85, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(86, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(87, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(88, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(89, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(90, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(91, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(92, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(93, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(94, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(95, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(96, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(97, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(98, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(99, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(100, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(101, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(102, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(103, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(104, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(105, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(106, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(107, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(108, 'namamam', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(109, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(110, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(111, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(112, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(113, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(114, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(115, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(116, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(117, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(118, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(119, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(120, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(121, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(122, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(123, '', '', '0000-00-00', 'Gender', '', 0, '', 'Select city', 'Select State', '', '', ''),
(124, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(125, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(126, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(127, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(128, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(129, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(130, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(131, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(132, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(133, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(134, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(135, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(136, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(137, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(138, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(139, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(140, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(141, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(142, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(143, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(144, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(145, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(146, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(147, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(148, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(149, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(150, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(151, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(152, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(153, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(154, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(155, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(156, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(157, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(158, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(159, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(160, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(161, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(162, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(163, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(164, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(165, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(166, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(167, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(168, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(169, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(170, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(171, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(172, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(173, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(174, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(175, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(176, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(177, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(178, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(179, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(180, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(181, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(182, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(183, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(184, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(185, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(186, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(187, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(188, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(189, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(190, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(191, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(192, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(193, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(194, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(195, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(196, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(197, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(198, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(199, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(200, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(201, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(202, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(203, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(204, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(205, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(206, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(207, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(208, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(209, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(210, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(211, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(212, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(213, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(214, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(215, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(216, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(217, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', ''),
(218, '', '', '0000-00-00', '', '', 0, '', 'Select city', 'Select State', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointement`
--
ALTER TABLE `appointement`
  ADD PRIMARY KEY (`app_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`pres_id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointement`
--
ALTER TABLE `appointement`
  MODIFY `app_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `pres_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=219;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
