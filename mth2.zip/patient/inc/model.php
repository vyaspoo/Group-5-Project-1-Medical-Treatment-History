<?php

class model
{
    public function insert($connection,$table,$data) {
        $c=  array_keys($data);
        $column=  implode(",", $c);
        $v= array_values($data);
        $values=  implode("','", $v);
        
        echo $q="insert into $table($column) values('$values')";
        $connection->query($q);
    }
    public function select($connection,$table) {
       //select * from table name
        $q="select * from $table";
        $result=$connection->query($q);
        $r = array();
        while ($row = $result->fetch_object()) {
            $r[]=$row;
        }
        return $r;
    }
     public function login($connection,$table,$data) {
        //select * from registration where username and password;
        $q="select * from $table where ";
        foreach ($data as $k=>$v)
        {
            $q.="$k='$v' and ";
        }
        $q=  rtrim($q," and");
       
        $result=$connection->query($q);
        return $result;
    }
}



function sendmail($subject, $msg, $email, $cc, $replyto = "", $replyname = "")
{
    require_once 'PHPMailer/PHPMailerAutoload.php';
    $mail = new PHPMailer();
    $mail->isSMTP();
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = "TLS";
    $mail->Host = 'smtp.gmail.com';
    $mail->Port = 587;
    $mail->Username = 'techsmtpmails@gmail.com';
    $mail->Password = 'techsmtpmails@#$2020';
    //$mail->SMTPDebug = 2;
    $mail->setFrom('techsmtpmails@gmail.com', 'Medical');
    if ($replyto) {
        $mail->AddReplyTo($replyto, $replyname);
    } else {
        $mail->AddReplyTo($email, 'Medical');
    }
    $mail->addAddress($email);
    if ($cc) {
        $mail->addCC($cc);
    }
    $mail->isHTML(true);
    $mail->Subject = $subject . " - " . date('d/m/Y');
    $mail->Body = $msg;
    if ($mail->send()) {
        //save_mail($mail);
        return 1;
    } else {
        //save_mail($mail);
        return 2;
        //return $mail->ErrorInfo;
    }
}

?>