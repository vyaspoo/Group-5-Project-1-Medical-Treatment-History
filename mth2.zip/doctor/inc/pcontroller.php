<?php
    include 'model.php';
    $model=new model();
    
    include 'connect.php';
    $obj=new connect();
    $con=$obj->get_connect();
     session_start();
     
     $alluser=$model->select($con,"prescription");
     
    if(isset($_REQUEST))
    {
        $name=$_REQUEST["pname"];
        $date=$_REQUEST["date"];
        $presc=$_FILES["file"]["name"];
        $presc1=$_FILES["file"]["tmp_name"];
        $symptoms=$_REQUEST["symptoms"];
        move_uploaded_file($presc1,"../img/".$presc);
        $data=array(
            "patient_name"=>$name,
            "pres_date"=>$date,
            "prescription"=>$presc,
            "symptoms"=>$symptoms,
            );
      $result=$model->insert($con,"prescription",$data);
      
    }
  header("Location: ../prescription.php");
      
?>