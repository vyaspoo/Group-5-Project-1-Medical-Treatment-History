<?php
error_reporting(0);
    class connect
    {
        public function get_connect()
        {
            $con=new mysqli("localhost","root","","mth");
            return $con;
        }
    }
?>