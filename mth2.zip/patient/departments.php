
<?php include './inc/header.php';?>
        <!-- –––––––––––––––[ HEADER ]––––––––––––––– -->

		<!-- –––––––––––––––[ PAGE CONTENT ]––––––––––––––– -->
		<main id="mainContent" class="main-content">
            
            <!-- Start Hero Area -->
            <section class="section breadcrumb-area pt-100 pb-80" data-bg-img="assets/images/slider/01.jpg">
                <div class="container t-center">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
                            <div class="section-top-title">
                                <h1 class="font-45">Departments</h1>
                                <ol class="breadcrumb">
                                    <li><a href="index-3.html"><i class="fa fa-home mr-10"></i>Home</a></li>
                                    <li class="active">Departments</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- End Hero Area -->

            <!-- Start Featured Works -->
            <section class="section popular-departements-area ptb-60 border-bottom">
                <div class="container">
                    <div class="row mb-30">
                        <div class="col-lg-7 col-md-8 col-sm-10 col-xs-12 col-xs-center t-center mb-40">
                            <h6 class="section-subtitle mb-10 t-uppercase color-mid">What treatment you looking</h6>
                            <h2 class="section-title mb-20 font-22 t-uppercase">MOST POPULAR DEPARTMETS</h2>
                            <div class="heart-line">
                                <img src="assets/images/icon.png" alt="Awesome Image">
                            </div>
                        </div>
                    </div>
                    <div class="departements-wrapper row row-tb-15">
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <a href="#" class="departement-single">
                                <div class="departement-img">
                                    <img src="assets/images/department/01.jpg" alt="">
                                    <span class="departement-icon">
                                        <i class="pos-center icon-i-dental"></i>
                                    </span>
                                </div>
                                <div class="departement-footer t-left">
                                    <div class="h5 departement-title color-theme pt-15 pb-10">Dental Care</div>
                                    <p class="color-mid">Cum sociis natoque penatibus et magnis dis parturient montesmus. Pro vel nibh et elit mollis commodo et nec augueique.</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <a href="#" class="departement-single">
                                <div class="departement-img">
                                    <img src="assets/images/department/02.jpg" alt="">
                                    <span class="departement-icon">
                                        <i class="pos-center icon-i-ear-nose-throat"></i>
                                    </span>
                                </div>
                                <div class="departement-footer t-left">
                                    <div class="h5 departement-title color-theme pt-15 pb-10">Otology</div>
                                    <p class="color-mid">Cum sociis natoque penatibus et magnis dis parturient montesmus. Pro vel nibh et elit mollis commodo et nec augueique.</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <a href="#" class="departement-single">
                                <div class="departement-img">
                                    <img src="assets/images/department/03.jpg" alt="">
                                    <span class="departement-icon">
                                        <i class="pos-center icon-i-cardiology"></i>
                                    </span>
                                </div>
                                <div class="departement-footer t-left">
                                    <div class="h5 departement-title color-theme pt-15 pb-10">Cardiac Clinic</div>
                                    <p class="color-mid">Cum sociis natoque penatibus et magnis dis parturient montesmus. Pro vel nibh et elit mollis commodo et nec augueique.</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <a href="#" class="departement-single">
                                <div class="departement-img">
                                    <img src="assets/images/department/04.jpg" alt="">
                                    <span class="departement-icon">
                                        <i class="pos-center icon-i-pediatrics"></i>
                                    </span>
                                </div>
                                <div class="departement-footer t-left">
                                    <div class="h5 departement-title color-theme pt-15 pb-10">Hepatology</div>
                                    <p class="color-mid">Cum sociis natoque penatibus et magnis dis parturient montesmus. Pro vel nibh et elit mollis commodo et nec augueique.</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <a href="#" class="departement-single">
                                <div class="departement-img">
                                    <img src="assets/images/department/05.jpg" alt="">
                                    <span class="departement-icon">
                                        <i class="pos-center icon-i-surgery"></i>
                                    </span>
                                </div>
                                <div class="departement-footer t-left">
                                    <div class="h5 departement-title color-theme pt-15 pb-10">Orthopedics</div>
                                    <p class="color-mid">Cum sociis natoque penatibus et magnis dis parturient montesmus. Pro vel nibh et elit mollis commodo et nec augueique.</p>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <a href="#" class="departement-single">
                                <div class="departement-img">
                                    <img src="assets/images/department/06.jpg" alt="">
                                    <span class="departement-icon">
                                        <i class="pos-center icon-i-internal-medicine"></i>
                                    </span>
                                </div>
                                <div class="departement-footer t-left">
                                    <div class="h5 departement-title color-theme pt-15 pb-10">Gastroenterology</div>
                                    <p class="color-mid">Cum sociis natoque penatibus et magnis dis parturient montesmus. Pro vel nibh et elit mollis commodo et nec augueique.</p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </section>
            <!-- End Featured Works -->

            <section class="section departements-area ptb-60">
                <div class="container">
                    <div class="row mb-30">
                        <div class="col-lg-7 col-md-8 col-sm-10 col-xs-12 col-xs-center t-center mb-40">
                            <h6 class="section-subtitle mb-10 t-uppercase color-mid">All departments</h6>
                            <h2 class="section-title mb-20 font-22 t-uppercase">Medical departments & centers</h2>
                            <div class="heart-line">
                                <img src="assets/images/icon.png" alt="Awesome Image">
                            </div>
                        </div>
                    </div>
                    <div class="departements-wrapper">
                        <div class="departement-cat mb-40">
                            <h4 class="departement-cat-header bg-gray">Nuclear Magnetic</h4>
                            <div class="departement-cat-body">
                                <ul class="row">
                                    <li class="col-sm-4">
                                        <ul>
                                            <li><a href="single-departement.html">Cardiac Surgery</a>
                                            </li>
                                            <li><a href="single-departement.html">Rehabilitation</a>
                                            </li>
                                            <li><a href="single-departement.html">Cardiac Surgery</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="col-sm-4">
                                        <ul>
                                            <li><a href="single-departement.html">Medicine</a>
                                            </li>
                                            <li><a href="single-departement.html">Dental Care Service</a>
                                            </li>
                                            <li><a href="single-departement.html">Outpatient Surgery</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="col-sm-4">
                                        <ul>
                                            <li><a href="single-departement.html">Physical Medicine</a>
                                            </li>
                                            <li><a href="single-departement.html">Sleep Disorders</a>
                                            </li>
                                            <li><a href="single-departement.html">Radiology Therapy</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="departement-cat mb-40">
                            <h4 class="departement-cat-header bg-gray">Dental Clinic Center</h4>
                            <div class="departement-cat-body">
                                <ul class="row">
                                    <li class="col-sm-4">
                                        <ul>
                                            <li><a href="single-departement.html">Medicine</a>
                                            </li>
                                            <li><a href="single-departement.html">Cardiac Surgery</a>
                                            </li>
                                            <li><a href="single-departement.html">Rehabilitation</a>
                                            </li>
                                            <li><a href="single-departement.html">Cardiac Surgery</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="col-sm-4">
                                        <ul>
                                            <li><a href="single-departement.html">Outpatient Surgery</a>
                                            </li>
                                            <li><a href="single-departement.html">Medicine</a>
                                            </li>
                                            <li><a href="single-departement.html">Dental Care Service</a>
                                            </li>
                                            <li><a href="single-departement.html">Outpatient Surgery</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="col-sm-4">
                                        <ul>
                                            <li><a href="single-departement.html">Dental Care Service</a>
                                            <li><a href="single-departement.html">Physical Medicine</a>
                                            </li>
                                            <li><a href="single-departement.html">Sleep Disorders</a>
                                            </li>
                                            <li><a href="single-departement.html">Radiology Therapy</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="departement-cat mb-40">
                            <h4 class="departement-cat-header bg-gray">Cardiology Center</h4>
                            <div class="departement-cat-body">
                                <ul class="row">
                                    <li class="col-sm-4">
                                        <ul>
                                            <li><a href="single-departement.html">Rehabilitation</a>
                                            </li>
                                            <li><a href="single-departement.html">Cardiac Surgery</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="col-sm-4">
                                        <ul>
                                            <li><a href="single-departement.html">Medicine</a>
                                            </li>
                                            <li><a href="single-departement.html">Outpatient Surgery</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="col-sm-4">
                                        <ul>
                                            <li><a href="single-departement.html">Physical Medicine</a>
                                            </li>
                                            <li><a href="single-departement.html">Sleep Disorders</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>



		</main>
		<!-- –––––––––––––––[ END PAGE CONTENT ]––––––––––––––– -->

		<!-- –––––––––––––––[ FOOTER ]––––––––––––––– -->
		<?php include './inc/footer.php';?>