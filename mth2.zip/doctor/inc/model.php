<?php

class model
{
    public function insert($connection,$table,$data) {
        $c=  array_keys($data);
        $column=  implode(",", $c);
        $v= array_values($data);
        $values=  implode("','", $v);
        
       $q="insert into $table($column)values('$values')";
        $connection->query($q);
    }
    public function select($connection,$table) {
       //select * from table name
        $q="select * from $table";
        $result=$connection->query($q);
        while ($row = $result->fetch_object()) {
            $r[]=$row;
        }
        return $r;
    }
     public function login($connection,$table,$data) {
        //select * from registration where username and password;
        $q="select * from $table where ";
        foreach ($data as $k=>$v)
        {
            $q.="$k='$v' and ";
        }
        $q=  rtrim($q," and");
       
        $result=$connection->query($q);
        return $result;
    }
}
?>