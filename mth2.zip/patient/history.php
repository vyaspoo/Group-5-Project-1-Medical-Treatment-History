       <?php include './inc/header.php';

       $appall = $con->query("SELECT * FROM `appointement` WHERE `patient_id` = '".$_SESSION["puserid"]."' ORDER BY `app_id` DESC");
       ?>
    
    <!-- topbar ends -->
       <style>
           table.table {
               width: 90%;
               text-align: center;
               margin: 0 auto;
           }
           th{text-align: center}
       </style>
<div class="ch-container">
    <div class="row">
        
        <!-- left menu starts -->
       <!--/span-->
        <!-- left menu ends -->

        <noscript>
            <div class="alert alert-block col-md-12">
                <h4 class="alert-heading">Warning!</h4>

                <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a>
                    enabled to use this site.</p>
            </div>
        </noscript>

       
   
    <div class="row">
        
                </div>
                <div class="box-content">
                    <table class="table table-bordered table-striped table-condensed">
                        <thead>
                        <tr>
                            <th>id</th>
                            <th>Doc_id</th>
                            <th>date</th>
                            <th>Message</th>
                            <th>Time</th>
                            <th>prescription</th>
                           
                            
                            
                        </tr>
                        </thead>

                        <tbody>
                        <?php $i=0; while ($rr = $appall->fetch_assoc()){ $i = $i+1;?>
                            <tr>
                                <td><?php echo $i; ?></td>
                                <td>Dr. Pooja</td>
                                <td><?php echo date("d/m/Y",strtotime($rr["date"])); ?></td>
                                <td><?php echo $rr["status"]; ?></td>
                                <td><?php echo $rr["from_time"]; ?></td>
                                <td><a>View</a></td>
                            </tr>
                        <?php } ?>
                        </tbody>
                    </table>
                                    </div>
            </div>
        </div>
    </div><!--/span-->

    <!-- content ends -->
    </div><!--/#content.col-md-0-->
</div><!--/fluid-row-->

    <!-- Ad, you can remove it -->
    <div class="row">
        <div class="col-md-9 col-lg-9 col-xs-9  hidden-xs">
            <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
            <!-- Charisma Demo 2 -->
            <ins class="adsbygoogle"
                 style="display:inline-block;width:728px;height:90px"
                 data-ad-client="ca-pub-5108790028230107"
                 data-ad-slot="3193373905"></ins>
            <script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
        </div>
      
    </div>
    <!-- Ad ends -->

    <hr>

    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">

        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">×</button>
                    <h3>Settings</h3>
                </div>
                <div class="modal-body">
                    <p>Here settings can be configured...</p>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
                    <a href="#" class="btn btn-primary" data-dismiss="modal">Save changes</a>
                </div>
            </div>
        </div>
    </div>
<?php include './inc/footer.php';?>