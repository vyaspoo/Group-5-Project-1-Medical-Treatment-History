<?php include './inc/header.php';?><!-- –––––––––––––––[ PAGE CONTENT ]––––––––––––––– -->
		<main id="mainContent" class="main-content">
            
            <!-- Start Hero Area -->
            <section class="section breadcrumb-area pt-100 pb-80" data-bg-img="assets/images/slider/01.jpg">
                <div class="container t-center">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1 col-xs-12 text-center">
                            <div class="section-top-title">
                                <h1 class="font-45">Doctor</h1>
                                <ol class="breadcrumb">
                                    <li><a href="index.php"><i class="fa fa-home mr-10"></i>Home</a></li>
                                    <li class="active">Doctor</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- End Hero Area -->

            <!-- Start Featured Works -->
            <section class="section single-departement-area ptb-30">
                <div class="container">
                    <div class="col-md-8 col-md-push-4 ptb-30">
                        <div class="row row-tb-5 row-rl-5">
                            <div class="col-xs-12">
                                <figure>
                                    <img src="images/doctor.jpg" alt="" style="height: 450px;width: 450px;margin-left: 20%;">
                                </figure>
                            </div>
                            
                        </div>
                        <div class="content-text pt-20">
                            <h6 class="t-uppercase color-theme mb-5">Optical Department</h6>
                            <h3 class="mb-10 font-24">See the difference and experience life in a new way</h3>
                            <p>Vivamus sem massa, cursus at mollis eu, euismod id risus. Vestibulum nunc ante, sagittis ut nisl at, porta porttitor justo. Nam imperdiet imperdiet volutpat. Sed vitae quam congue, tincidunt nisi et, volutpat lacus. Nullam porttitor porta augue vel iaculis. Pellentesque a pretium erat. Maecenas semper laoreet dapibus.</p>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus pretium orci sit amet mi ullamcorper egestas. Sed non mattis metus. Integer vel lorem tincidunt, pharetra eros nec, posuere odio. Nullam eget bibendum sem, venenatis lacinia justo. Duis aliquet lobortis neque, eget volutpat nulla iaculis a. Morbi iaculis, quam a facilisis condimentum, risus erat tincidunt dolor, ac interdum lorem urna non augue. In hac habitasse platea dictumst. Praesent condimentum justo justo, at ultricies diam accumsan vitae. Donec ac elementum diam.</p>
                        </div>
                    </div>
                    <div class="col-md-4 col-md-pull-8 ptb-30">
                                    <!-- Start Features Boxes Area -->
            <aside class="features-boxes-area sidebar-features-area color-white">
               
                
                <div class="features-boxe-single bg-blue-darker p-30" style="margin-top: 50%;">
                    <h4 class="mb-10 t-uppercase">Opening Hours</h4>
                    <ul class="opening-hours">
                        <li>Monday – Thursday <span class="float-right">8.00 – 17.00</span></li>
                        <li>Friday <span class="float-right">9.30 – 17.30</span></li>
                        <li>Saturday - Sunday <span class="float-right">Closing</span></li>
                    </ul>
                </div>
            </aside>
                                    <a href="appointment.php" class="btn btn-o btn-rounded" style="margin-top: 10%;">Make Appoinment</a>
                                    <a href="inquiry.php" class="btn btn-o btn-rounded" style="margin-top: 10%;">Inquiry</a>
            </div>
                    
                </div>
                
                
            </section>
            <!-- End Featured Works -->
            <!-- Start Reviews Area -->
            <section class="section reviews-area pt-30 pb-60">
                <div class="container">
                    <h2 class="mb-40 font-22 h-title" style="margin-left: 40%;">Reviews About Dr.Ruhi</h2>
                    <div class="row row-tb-15">
                        <div class="col-sm-6">
                            <div class="review-single pos-r bg-lighter p-20">
                                <h5 class="t-uppercase mb-5 color-theme">ALEX MARTINES</h5>
                                <div class="mb-15">April 29, 2016</div>
                                <p class="color-mid mb-10">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus pretium orci sit amet mi ullamcorper egestas. Sed non mattis metus. Integer vel lorem tincidunt, pharetra eros nec, posuere odio. Nullam eget bibendum sem.</p>
                                <div class="rating pos-a top-20 right-20 pr-5">
                                    <span class="rating-stars">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star-o"></i>
                                        <i class="fa fa-star-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="review-single pos-r bg-lighter p-20">
                                <h5 class="t-uppercase mb-5 color-theme">ALEX MARTINES</h5>
                                <div class="mb-15">April 29, 2016</div>
                                <p class="color-mid mb-10">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus pretium orci sit amet mi ullamcorper egestas. Sed non mattis metus. Integer vel lorem tincidunt, pharetra eros nec, posuere odio. Nullam eget bibendum sem.</p>
                                <div class="rating pos-a top-20 right-20 pr-5">
                                    <span class="rating-stars">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star-o"></i>
                                        <i class="fa fa-star-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="review-single pos-r bg-lighter p-20">
                                <h5 class="t-uppercase mb-5 color-theme">ALEX MARTINES</h5>
                                <div class="mb-15">April 29, 2016</div>
                                <p class="color-mid mb-10">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus pretium orci sit amet mi ullamcorper egestas. Sed non mattis metus. Integer vel lorem tincidunt, pharetra eros nec, posuere odio. Nullam eget bibendum sem.</p>
                                <div class="rating pos-a top-20 right-20 pr-5">
                                    <span class="rating-stars">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star-o"></i>
                                        <i class="fa fa-star-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="review-single pos-r bg-lighter p-20">
                                <h5 class="t-uppercase mb-5 color-theme">ALEX MARTINES</h5>
                                <div class="mb-15">April 29, 2016</div>
                                <p class="color-mid mb-10">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus pretium orci sit amet mi ullamcorper egestas. Sed non mattis metus. Integer vel lorem tincidunt, pharetra eros nec, posuere odio. Nullam eget bibendum sem.</p>
                                <div class="rating pos-a top-20 right-20 pr-5">
                                    <span class="rating-stars">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star-o"></i>
                                        <i class="fa fa-star-o"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </section>
            <!-- End Reviews Area -->            <!-- Start Our Team Area -->
            
            <!-- End Our Team Area -->
            <!-- Start appointment Area -->
            
            <!-- Start appointment Area -->
		</main>
		<!-- –––––––––––––––[ END PAGE CONTENT ]––––––––––––––– -->

		<?php include './inc/footer.php';?>