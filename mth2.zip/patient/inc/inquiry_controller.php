<?php
    include '../inc/model.php';
    $model=new model();
    
    
    include '../inc/connect.php';
    $obj=new connect();
    $con=$obj->get_connect();
    session_start();
 
    if(isset($_REQUEST))
    {
        $name=$_REQUEST["name"];
        $email=$_REQUEST["email"];
        $date=$_REQUEST["date"];
        $phone=$_REQUEST["phone"];
        $msg=$_REQUEST["message"];
        
        $data=array(
            "name"=>$name,
            "email"=>$email,
            "date"=>date("Y-m-d",strtotime($date)),
            "phone"=>$phone,
            "message"=>$msg
        );
        $result=$model->insert($con,"p_inquiry",$data);
    }
    header("Location: ../inquiry.php");