<?php
    include 'model.php';
    $model=new model();

    include 'connect.php';
    $obj=new connect();
    $con=$obj->get_connect();
     session_start();
    if(isset($_POST))
    {
        $email = $_REQUEST["email"];
        $appall = $con->query("SELECT * FROM `registration` WHERE `email` = '".$email."' ORDER BY `id` DESC");
        if(!$appall->num_rows){
            $st = "?st=0";
            header("Location: ../forgot.php".$st);
        }else{
            $st = "?st=1";
            $check1 = $appall->fetch_assoc();
            $msg = "Hello,<br><br>Your login details for <b>Medicine App</b> :<br><br>Email : ".$check1["email"]."<br>Password : ".$check1['password']."<br><br>Thanks,<br>Medicine App.";
            sendmail("Forgot Password - Medicine App", $msg, $check1['email'],"");
            header("Location: ../login.php".$st);
        }
    }
    exit;
?>